package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;


import view.view_lienzo;

public class logic_view_lienza implements ActionListener, KeyListener{
	private view_lienzo vl;
	private subprocessMoveObject hilo1;
	public logic_view_lienza(view_lienzo vl) {
		this.vl=vl;
		this.vl.btn_start.addActionListener(this);
		this.vl.btn_stop.addActionListener(this);
		this.vl.btn_resumen.addActionListener(this);
		this.vl.btn_start.addKeyListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==vl.btn_start) {
			hilo1=new subprocessMoveObject(vl);
			hilo1.start();
			
		}else if(e.getSource()==vl.btn_stop) {
			hilo1.suspend();
			
		}else if(e.getSource()==vl.btn_resumen) {
			hilo1.resume();
			
		}
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		if(e.getKeyCode()==e.VK_UP) {
			vl.pn_lienzo.setJugadorY(-5);
		}else if(e.getKeyCode()==e.VK_DOWN) {
			vl.pn_lienzo.setJugadorY(5);
		}else if(e.getKeyCode()==e.VK_LEFT) {
			vl.pn_lienzo.setJugadorX(-5);
		}else if(e.getKeyCode()==e.VK_RIGHT) {
			vl.pn_lienzo.setJugadorX(5);
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		if (vl.pn_lienzo.hayColision()) {
            System.out.println("¡Boom! ¡Colisión detectada!");
            
        }
	}
	
	

}
