package controller;
import view.view_lienzo;

public class subprocessMoveObject extends Thread {
	private view_lienzo vl;
	private boolean flag=true;
	public subprocessMoveObject(view_lienzo vl_) {
		this.vl=vl_;
	}
	private int getRandomX() {
		return(int)(Math.random()*vl.pn_lienzo.getWidth());
	}private int getRandomY() {
		return(int)(Math.random()*vl.pn_lienzo.getHeight());
	}
	public void run() {
		while(flag) {
			try {
				sleep(5000);
				vl.pn_lienzo.setObjeto1(getRandomX(),getRandomY());
			}catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
			
		}
		
	}
	public void setFlag(boolean flag) {
		this.flag=flag;
	}
}
