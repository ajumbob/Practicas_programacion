package view;
import controller.*;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class view_lienzo extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	public JButton btn_start;
	public JButton btn_stop;
	public JButton btn_resumen;
	public lienzo pn_lienzo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					view_lienzo frame = new view_lienzo();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public view_lienzo() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 420, 350);
		setResizable(false);
		setTitle("Este tema amaste");
		contentPane = new JPanel();
		contentPane.setBackground(Color.GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel pn_control = new JPanel();
		pn_control.setBounds(12, 35, 400, 30);
		contentPane.add(pn_control);
		
		btn_start = new JButton("Star");
		pn_control.add(btn_start);
		
		btn_stop = new JButton("Stop");
		btn_stop.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		pn_control.add(btn_stop);
		
		btn_resumen = new JButton("resumen");
		pn_control.add(btn_resumen);
		
		pn_lienzo = new lienzo();
		pn_lienzo.setBounds(22, 76, 400, 200);
		contentPane.add(pn_lienzo);
		new logic_view_lienza(this);

	}
}
