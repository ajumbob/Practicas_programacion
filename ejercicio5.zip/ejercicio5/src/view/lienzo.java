package view;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class lienzo extends JPanel{
	private Point jugador=new Point(10,90);
	private Point objeto1=new Point(10,20);
	public lienzo() {
		repaint();
		
	}
	public void paint(Graphics g) {
		ImageIcon img = new ImageIcon("src/img/pika.png");
		g.drawImage(img.getImage(), 0, 0,getWidth(),getHeight(),null);
		g.setColor(Color.blue);
		g.drawRect(objeto1.x, objeto1.y, 50, 50);
		g.setColor(Color.red);
		g.fillRect(objeto1.x+5, objeto1.y+5, 40, 40);
		g.setColor(Color.black);
		g.fillOval(jugador.x,jugador.y, 30, 30);//keylistener
		g.setColor(Color.green);
		g.drawOval(10, 140, 50, 50);
		int[] xTriangulo = {35, 50, 20};
		int[] yTriangulo = {145, 180, 180};
		g.setColor(Color.CYAN);
		g.fillPolygon(xTriangulo, yTriangulo, 3);
	}
	public void setJugadorX(int x) {
		int nuevaX = this.jugador.x + x;
        if (nuevaX >= 0 && nuevaX <= getWidth() - 30) {
            this.jugador.x = nuevaX;
        }
        repaint();
	}
	public void setJugadorY(int y) {
		int nuevaY = this.jugador.y + y;
        if (nuevaY >= 0 && nuevaY <= getHeight() - 30) {
            this.jugador.y = nuevaY;
        }
        repaint();
	}
	public void setObjeto1(int x,int y) {
		objeto1.setLocation(x,y);
		repaint();
	}
	public boolean hayColision() {
        Rectangle rJugador = new Rectangle(jugador.x, jugador.y, 30, 30);
        Rectangle rObjeto = new Rectangle(objeto1.x, objeto1.y, 50, 50);
        return rJugador.intersects(rObjeto);
    }
//	public void setObjeto1X(int x) {
	//	this.objeto1.x=x;
		//repaint();
//	}
	//public void setObjeto1Y(int y) {
		//this.objeto1.y=y;
		//repaint();
	//}

}
