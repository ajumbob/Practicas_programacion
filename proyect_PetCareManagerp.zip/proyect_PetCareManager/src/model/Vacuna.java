package model;

public class Vacuna {
    private int idVacuna;
    private String nombre;
    private String descripcion;

    public Vacuna() {}

    public Vacuna(int idVacuna, String nombre, String descripcion) {
        this.idVacuna = idVacuna;
        this.nombre = nombre;
        this.descripcion = descripcion;
    }

    public int getIdVacuna() {
        return idVacuna;
    }

    public void setIdVacuna(int idVacuna) {
        this.idVacuna = idVacuna;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    // Método clave para que el JComboBox de ViewVacunas funcione visualmente
    @Override
    public String toString() {
        return this.nombre;
    }
}