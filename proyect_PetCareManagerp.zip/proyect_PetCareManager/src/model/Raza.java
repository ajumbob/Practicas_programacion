package model;

public class Raza {
    private int idRaza;
    private String nombre;
    private int idEspecie;

    public Raza() {}

    public Raza(int idRaza, String nombre, int idEspecie) {
        this.idRaza = idRaza;
        this.nombre = nombre;
        this.idEspecie = idEspecie;
    }

    public int getIdRaza() {
        return idRaza;
    }

    public void setIdRaza(int idRaza) {
        this.idRaza = idRaza;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getIdEspecie() {
        return idEspecie;
    }

    public void setIdEspecie(int idEspecie) {
        this.idEspecie = idEspecie;
    }

    // Método clave para que el JComboBox muestre el nombre y no la memoria
    @Override
    public String toString() {
        return this.nombre;
    }
}