package model;

import java.time.LocalDate;

public class Mascota {
    private int idMascota;
    private String nombre;
    private String sexo; // Puede ser 'Macho' o 'Hembra'
    private LocalDate fechaNacimiento; 
    private String color;
    private double peso;
    
    // Llaves foráneas
    private int idPropietario;
    private int idEspecie;
    private int idRaza;

    public Mascota() {}

    public Mascota(int idMascota, String nombre, String sexo, LocalDate fechaNacimiento, String color, double peso, int idPropietario, int idEspecie, int idRaza) {
        this.idMascota = idMascota;
        this.nombre = nombre;
        this.sexo = sexo;
        this.fechaNacimiento = fechaNacimiento;
        this.color = color;
        this.peso = peso;
        this.idPropietario = idPropietario;
        this.idEspecie = idEspecie;
        this.idRaza = idRaza;
    }

	public int getIdMascota() {
		return idMascota;
	}

	public void setIdMascota(int idMascota) {
		this.idMascota = idMascota;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	public LocalDate getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(LocalDate fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public double getPeso() {
		return peso;
	}

	public void setPeso(double peso) {
		this.peso = peso;
	}

	public int getIdPropietario() {
		return idPropietario;
	}

	public void setIdPropietario(int idPropietario) {
		this.idPropietario = idPropietario;
	}

	public int getIdEspecie() {
		return idEspecie;
	}

	public void setIdEspecie(int idEspecie) {
		this.idEspecie = idEspecie;
	}

	public int getIdRaza() {
		return idRaza;
	}

	public void setIdRaza(int idRaza) {
		this.idRaza = idRaza;
	}

    
}