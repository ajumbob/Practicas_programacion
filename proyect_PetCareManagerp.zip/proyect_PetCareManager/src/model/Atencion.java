package model;

import java.time.LocalDate;

public class Atencion {
    // Asegúrate de tener estos atributos (o ajusta los nombres si los tuyos son distintos)
    private int idAtencion;
    private int idCita;
    private LocalDate fecha;
    private String diagnostico;
    private String tratamiento;
    private String observacion;
    private boolean internamiento;

    // ESTE ES EL CONSTRUCTOR QUE EL CONTROLADOR NECESITA
    public Atencion(int idAtencion, int idCita, LocalDate fecha, String diagnostico, 
                    String tratamiento, String observacion, boolean internamiento) {
        this.idAtencion = idAtencion;
        this.idCita = idCita;
        this.fecha = fecha;
        this.diagnostico = diagnostico;
        this.tratamiento = tratamiento;
        this.observacion = observacion;
        this.internamiento = internamiento;
    }

	public int getIdAtencion() {
		return idAtencion;
	}

	public void setIdAtencion(int idAtencion) {
		this.idAtencion = idAtencion;
	}

	public int getIdCita() {
		return idCita;
	}

	public void setIdCita(int idCita) {
		this.idCita = idCita;
	}

	public LocalDate getFecha() {
		return fecha;
	}

	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}

	public String getDiagnostico() {
		return diagnostico;
	}

	public void setDiagnostico(String diagnostico) {
		this.diagnostico = diagnostico;
	}

	public String getTratamiento() {
		return tratamiento;
	}

	public void setTratamiento(String tratamiento) {
		this.tratamiento = tratamiento;
	}

	public String getObservacion() {
		return observacion;
	}

	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}

	public boolean isInternamiento() {
		return internamiento;
	}

	public void setInternamiento(boolean internamiento) {
		this.internamiento = internamiento;
	}

    // Asegúrate de tener los getters y setters aquí abajo...
    
}