package model;
import Libreria_generica.Entidad;

public class CatalogoVacuna extends Entidad<String> {
    private String nombre;

    public CatalogoVacuna() {}

    public CatalogoVacuna(String id, String nombre) {
        this.setId(id);
        this.nombre = nombre;
    }

    public CatalogoVacuna(String[] datos) {
        this.setId(datos[0]);
        this.nombre = datos[1];
    }

    public String getNombre() { return nombre; }

    @Override
    public String info() {
        return getId() + "," + nombre;
    }
}
