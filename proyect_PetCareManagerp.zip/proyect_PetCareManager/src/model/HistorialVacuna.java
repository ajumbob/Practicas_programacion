package model;

import java.time.LocalDate;

public class HistorialVacuna {
    private int idHistorial;
    private LocalDate fecha;
    private LocalDate proximaDosis;
    
    // Llaves foráneas
    private int idMascota;
    private int idVacuna;

    public HistorialVacuna() {}

    public HistorialVacuna(int idHistorial, LocalDate fecha, LocalDate proximaDosis, int idMascota, int idVacuna) {
        this.idHistorial = idHistorial;
        this.fecha = fecha;
        this.proximaDosis = proximaDosis;
        this.idMascota = idMascota;
        this.idVacuna = idVacuna;
    }

	public int getIdHistorial() {
		return idHistorial;
	}

	public void setIdHistorial(int idHistorial) {
		this.idHistorial = idHistorial;
	}

	public LocalDate getFecha() {
		return fecha;
	}

	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}

	public LocalDate getProximaDosis() {
		return proximaDosis;
	}

	public void setProximaDosis(LocalDate proximaDosis) {
		this.proximaDosis = proximaDosis;
	}

	public int getIdMascota() {
		return idMascota;
	}

	public void setIdMascota(int idMascota) {
		this.idMascota = idMascota;
	}

	public int getIdVacuna() {
		return idVacuna;
	}

	public void setIdVacuna(int idVacuna) {
		this.idVacuna = idVacuna;
	}

    
}