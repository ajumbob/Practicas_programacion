package model;

public class Usuario {
    private int idUsuario;
    private String nombre; // Nombre completo del usuario
    private String username; // El usuario para loguearse
    private String password;
    private String correo;
    
    // Llave foránea
    private int idRol;

    public Usuario() {}

    public Usuario(int idUsuario, String nombre, String username, String password, String correo, int idRol) {
        this.idUsuario = idUsuario;
        this.nombre = nombre;
        this.username = username;
        this.password = password;
        this.correo = correo;
        this.idRol = idRol;
    }

	public int getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(int idUsuario) {
		this.idUsuario = idUsuario;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public int getIdRol() {
		return idRol;
	}

	public void setIdRol(int idRol) {
		this.idRol = idRol;
	}

    
}