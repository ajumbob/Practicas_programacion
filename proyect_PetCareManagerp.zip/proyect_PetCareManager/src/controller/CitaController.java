package controller;

import dao.CitaDAO;
import model.Cita;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.regex.Pattern;

public class CitaController {
    
    private CitaDAO dao = new CitaDAO();
    
    // Mantenemos tus validaciones originales
    private static final String REGEX_FECHA = "^(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[012])/\\d{4}$";
    private static final String REGEX_HORA = "^([01]\\d|2[0-3]):([0-5]\\d)$";

    public boolean validarFormatos(String fecha, String hora) {
        boolean fechaValida = Pattern.matches(REGEX_FECHA, fecha);
        boolean horaValida = Pattern.matches(REGEX_HORA, hora);
        return fechaValida && horaValida;
    }

    public boolean agendarCita(int idMascota, String fechaTexto, String horaTexto, String motivo) {
        try {
            // 1. Convertir los strings del formulario a objetos de tiempo de Java
            DateTimeFormatter formatoFecha = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            LocalDate fecha = LocalDate.parse(fechaTexto, formatoFecha);
            LocalTime hora = LocalTime.parse(horaTexto); // LocalTime parsea "HH:mm" por defecto
            
            // 2. Construir el objeto Cita
            // Ponemos idCita en 0 (MySQL lo autogenera)
            // Ponemos idVeterinario en 0 (No lo estamos usando aún en la vista)
            Cita nuevaCita = new Cita(0, fecha, hora, motivo, "Pendiente", idMascota, 0);
            
            // 3. Delegar al DAO
            return dao.agendarCita(nuevaCita);
            
        } catch (Exception e) {
            System.err.println("Error al parsear los datos de tiempo: " + e.getMessage());
            return false;
        }
    }
}