package controller;

import dao.HistorialVacunaDAO;
import model.HistorialVacuna;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.regex.Pattern;

public class VacunaController {

    private HistorialVacunaDAO dao = new HistorialVacunaDAO();
    private static final String REGEX_FECHA = "^(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[012])/\\d{4}$";

    public String validarFormatos(String fecha) {
        if (!Pattern.matches(REGEX_FECHA, fecha)) return "Formato de fecha incorrecto (use DD/MM/AAAA).";
        return "OK";
    }

    public boolean registrarVacuna(int idMascota, int idVacuna, String fechaTexto) {
        try {
            DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            LocalDate fecha = LocalDate.parse(fechaTexto, formato);
            
            // Creamos el registro (id_historial = 0, proxima_dosis = null por ahora)
            HistorialVacuna hv = new HistorialVacuna(0, fecha, null, idMascota, idVacuna);
            
            return dao.registrar(hv);
        } catch (Exception e) {
            System.err.println("Error al procesar la vacuna: " + e.getMessage());
            return false;
        }
    }
}