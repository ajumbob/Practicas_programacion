package controller;

import dao.VacunaDAO;
import model.Vacuna;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class CatalogoVacunaController {
    
    // Instanciamos tu nuevo DAO conectado a MySQL
    private VacunaDAO dao = new VacunaDAO();

    private static final String REGEX_NOMBRE = "^[a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ\\s]{3,50}$";

    public String validarFormato(String nombre) {
        if (!Pattern.matches(REGEX_NOMBRE, nombre)) return "El nombre de la vacuna es inválido o muy corto.";
        return "OK";
    }

    public boolean registrarVacunaCatalogo(String nombre) {
        // El ID va en 0 porque MySQL lo genera automáticamente. 
        // Agregamos "Sin descripción" por defecto ya que tu ventana anterior solo pedía el nombre.
        Vacuna nueva = new Vacuna(0, nombre, "Sin descripción");
        
        // Llamamos al método registrar de tu VacunaDAO
        return dao.registrar(nueva);
    }

    // OJO: El parámetro ahora debe ser int (entero) y no String
    public boolean eliminarVacunaCatalogo(int idVacuna) {
        return dao.eliminar(idVacuna);
    }

    public List<String[]> listar() {
        List<String[]> listaStrings = new ArrayList<>();
        
        // Traemos los objetos reales desde MySQL
        List<Vacuna> listaVacunas = dao.listarTodos();
        
        // Los transformamos en un arreglo de Strings para que tu JTable los pueda dibujar sin problemas
        for (Vacuna v : listaVacunas) {
            listaStrings.add(new String[]{
                String.valueOf(v.getIdVacuna()),
                v.getNombre()
            });
        }
        return listaStrings;
    }
}