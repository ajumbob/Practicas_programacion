package controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

// Importamos el DAO y el Modelo
import dao.AtencionDAO;
import model.Atencion; 

public class AtencionController {

    /**
     * Método para validar que los textos ingresados sean correctos.
     */
    public String validarFormatos(String peso, String temp, String diag, String trat, String obs) {
        if (diag == null || diag.trim().isEmpty()) {
            return "El diagnóstico no puede estar vacío.";
        }
        if (trat == null || trat.trim().isEmpty()) {
            return "El tratamiento no puede estar vacío.";
        }
        if (obs == null || obs.trim().isEmpty()) {
            return "La observación no puede estar vacía.";
        }
        return "OK";
    }

    /**
     * Método que recibe los datos de la vista, procesa la fecha y registra en BD.
     */
    public boolean registrarAtencion(int idCita, String fecha, String diagnostico, String tratamiento, String observacion, boolean internamiento) {
        try {
            // ===============================================================
            // SOLUCIÓN: Usamos el formato Año-Mes-Día (yyyy-MM-dd)
            // Esto coincide con "2026-07-27" que recibe la app.
            // ===============================================================
            DateTimeFormatter formato = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate fechaAtencion = LocalDate.parse(fecha.trim(), formato);

            // Instanciamos el DAO 
            AtencionDAO dao = new AtencionDAO();
            
            // Empaquetamos todo en el objeto Atencion
            // (Si tu constructor en model.Atencion no usa el 0, bórralo, pero el orden debe ser igual)
            Atencion nuevaAtencion = new Atencion(0, idCita, fechaAtencion, diagnostico, tratamiento, observacion, internamiento);
            
            // Guardamos en la base de datos
            return dao.registrar(nuevaAtencion);

        } catch (DateTimeParseException e) {
            System.err.println("Error en formato de fecha (esperado yyyy-MM-dd): " + e.getMessage());
            return false;
        } catch (Exception e) {
            System.err.println("Error al procesar el registro médico: " + e.getMessage());
            return false;
        }
    }

    /**
     * Método utilizado por la ViewHistorial para cargar datos.
     */
    public List<String[]> obtenerHistorialMedico(int idMascota) {
        try {
            AtencionDAO dao = new AtencionDAO();
            return dao.obtenerHistorialPorMascota(idMascota);
        } catch (Exception e) {
            System.err.println("Error al obtener el historial médico: " + e.getMessage());
            return new ArrayList<>(); 
        }
    }
}