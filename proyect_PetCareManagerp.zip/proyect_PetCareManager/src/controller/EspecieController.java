package controller;

import dao.EspecieDAO;
import model.Especie;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class EspecieController {
    
    // Instanciamos tu nuevo DAO conectado a MySQL
    private EspecieDAO dao = new EspecieDAO();

    private static final String REGEX_NOMBRE = "^[A-Za-zñÑáéíóúÁÉÍÓÚ\\s]{2,30}$";

    public String validarFormato(String nombre) {
        if (!Pattern.matches(REGEX_NOMBRE, nombre)) return "El tipo de mascota solo debe contener letras (mínimo 2 caracteres).";
        return "OK";
    }

    public boolean registrarEspecie(String nombre) {
        // Creamos la especie con ID 0 (MySQL lo autogenera)
        Especie nueva = new Especie(0, nombre);
        
        // Llamamos al método registrar de MySQL
        return dao.registrar(nueva);
    }

    // ⚠️ ATENCIÓN: El ID de la especie ahora es numérico (int), no texto (String)
    public boolean eliminarEspecie(int id) {
        return dao.eliminar(id);
    }

    public List<String[]> listar() {
        List<String[]> listaStrings = new ArrayList<>();
        
        // Traemos los objetos reales desde MySQL
        List<Especie> listaEspecies = dao.listarTodos();
        
        // Los transformamos en un arreglo de Strings para que tu JTable pueda dibujarlos
        for (Especie e : listaEspecies) {
            listaStrings.add(new String[]{
                String.valueOf(e.getIdEspecie()),
                e.getNombre()
            });
        }
        return listaStrings;
    }
}