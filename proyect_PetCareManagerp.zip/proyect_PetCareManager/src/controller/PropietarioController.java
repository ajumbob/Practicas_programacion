package controller;

import dao.PropietarioDAO;
import model.Propietario;
import java.util.regex.Pattern;

public class PropietarioController {
    
    private PropietarioDAO dao = new PropietarioDAO();

    // ... (Tus validaciones REGEX se mantienen exactamente igual) ...

    public boolean registrarPropietario(String cedula, String nombres, String apellidos, String telefono, String direccion, String correo) {
        // Creamos el objeto (el ID se pone en 0 porque MySQL lo autogenera)
        Propietario nuevo = new Propietario(0, cedula, nombres, apellidos, telefono, direccion, correo);
        
        // El DAO se encarga de todo el trabajo sucio con la base de datos
        return dao.registrar(nuevo);
    }
}