package controller;

import dao.UsuarioDAO;
import model.Usuario;
import java.util.regex.Pattern;

public class LoginController {

    private UsuarioDAO dao = new UsuarioDAO();

    // REGLAS DE EXPRESIONES REGULARES (Se mantienen igual)
    private static final String REGEX_USUARIO = "^[a-zA-Z0-9]{4,15}$";
    private static final String REGEX_CLAVE = "^\\S{6,}$";

    // Método para validar las expresiones regulares antes de ir a la BD
    public boolean validarFormato(String username, String password) {
        boolean userValido = Pattern.matches(REGEX_USUARIO, username);
        boolean passValida = Pattern.matches(REGEX_CLAVE, password);
        return userValido && passValida;
    }

    // Método que ahora se comunica con MySQL a través del DAO
    public boolean validarLogin(String username, String password) {
        Usuario u = dao.validarLogin(username, password);
        
        // Si 'u' no es null, significa que las credenciales son correctas
        return u != null; 
    }
}
