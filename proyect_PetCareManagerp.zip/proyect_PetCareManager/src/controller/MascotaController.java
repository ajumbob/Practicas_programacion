package controller;

import dao.MascotaDAO;
import model.Mascota;
import java.time.LocalDate;
import java.util.regex.Pattern;

public class MascotaController {
    
    private MascotaDAO dao = new MascotaDAO();

    // Mantenemos tu Regex original para validar textos limpios
    private static final String REGEX_TEXTO_LETRAS = "^[A-Za-zñÑáéíóúÁÉÍÓÚ\\s]{2,50}$";

    /**
     * Valida que los datos cumplan con las reglas de negocio antes de tocar la base de datos.
     */
    public String validarFormatos(String nombre, String color, double peso, int idPropietario, int idEspecie, int idRaza) {
        if (!Pattern.matches(REGEX_TEXTO_LETRAS, nombre)) {
            return "El nombre de la mascota solo debe contener letras.";
        }
        if (!Pattern.matches(REGEX_TEXTO_LETRAS, color)) {
            return "El color solo debe contener letras.";
        }
        if (peso <= 0 || peso >= 200) {
            return "El peso ingresado no es lógico (debe ser mayor a 0 y menor a 200 kg).";
        }
        if (idPropietario <= 0) {
            return "Error interno: El propietario seleccionado no tiene un ID válido.";
        }
        if (idEspecie <= 0 || idRaza <= 0) {
            return "Error interno: La especie o raza seleccionada no tiene un ID válido.";
        }
        
        return "OK";
    }

    /**
     * Recibe los datos tipados desde ViewMascota, valida y delega al DAO.
     */
    public boolean registrarMascota(String nombre, String sexo, LocalDate fechaNacimiento, String color, double peso, int idPropietario, int idEspecie, int idRaza) {
        
        // 1. Validar reglas de negocio
        String validacion = validarFormatos(nombre, color, peso, idPropietario, idEspecie, idRaza);
        if (!validacion.equals("OK")) {
            // En proyectos más grandes de Java, aquí lanzaríamos una Excepción personalizada 
            // (ej. throw new ValidacionException(validacion);) para que la vista la capture.
            System.err.println("Validación fallida: " + validacion);
            return false;
        }

        // 2. Construir el POJO
        // El ID de la mascota se envía como 0 porque MySQL tiene AUTO_INCREMENT
        Mascota nuevaMascota = new Mascota(0, nombre, sexo, fechaNacimiento, color, peso, idPropietario, idEspecie, idRaza);
        
        // 3. Delegar persistencia al DAO
        return dao.registrar(nuevaMascota);
    }
}