package util;

/**
 * Configuración centralizada para las notificaciones (correo, WhatsApp) y
 * la conexión con el Arduino.
 *
 * IMPORTANTE: Debes reemplazar estos valores por los tuyos antes de usar
 * el sistema. No subas tus credenciales reales a un repositorio público.
 */
public class ConfigNotificaciones {

    // ================= CORREO (Gmail + JavaMail) =================
    // Correo desde el cual se enviarán las notificaciones.
    public static final String EMAIL_REMITENTE = "petcaremanager.notificaciones@gmail.com";
    // Contraseña de APLICACIÓN de Gmail (NO tu contraseña normal).
    // Se genera en: https://myaccount.google.com/apppasswords
    public static final String EMAIL_CLAVE_APP = "ijuu ejug pqvz jhth\n"+ "";

    // ================= WHATSAPP (CallMeBot) =================
    // Número de WhatsApp registrado en CallMeBot, con códijgo de país, sin "+".
    // Ej: 593987654321
    public static final String CALLMEBOT_TELEFONO = "593962566939";
    // API Key que te entrega CallMeBot al activar el bot (te llega por WhatsApp).
    public static final String CALLMEBOT_APIKEY = "9876543";

    // ================= ARDUINO =================
    // Nombre del puerto serial donde está conectado el Arduino.
    // Windows: "COM3", "COM4", etc. Linux: "/dev/ttyUSB0" o "/dev/ttyACM0".
    public static final String ARDUINO_PUERTO = "COM3";
    public static final int ARDUINO_BAUDRATE = 9600;

    // Interruptores generales: en true activan el envío real.
    // Ponlos en false para pruebas (todo se imprime en consola, nada se envía).
    public static final boolean EMAIL_ACTIVO = true;
    public static final boolean WHATSAPP_ACTIVO = true;
    public static final boolean ARDUINO_ACTIVO = true;
}
