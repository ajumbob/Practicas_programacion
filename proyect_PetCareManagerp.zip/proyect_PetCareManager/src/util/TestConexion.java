package util;

import java.sql.Connection;

public class TestConexion {

    public static void main(String[] args) {

        Connection cn = ConexionBD.conectar();

        if(cn!=null){

            System.out.println("Conectado correctamente.");

        }else{

            System.out.println("No se pudo conectar.");

        }

    }

}