package util;

import com.fazecast.jSerialComm.SerialPort;

public class ArduinoController {

    private static final String PUERTO = "/dev/ttyACM0";
    private static final int BAUDRATE = 9600;

    private static SerialPort puerto;

    static {

        puerto = SerialPort.getCommPort(PUERTO);

        puerto.setBaudRate(BAUDRATE);
        puerto.setNumDataBits(8);
        puerto.setNumStopBits(1);
        puerto.setParity(SerialPort.NO_PARITY);

        if (puerto.openPort()) {

            System.out.println("Arduino conectado en "
                    + puerto.getSystemPortName());

        } else {

            System.err.println("No se pudo conectar con el Arduino.");

        }

    }

    private static void enviar(char comando){

        if(puerto != null && puerto.isOpen()){

            puerto.writeBytes(new byte[]{(byte)comando},1);

        }else{

            System.err.println("Puerto serial cerrado.");

        }

    }

    public static void indicarInternamiento(){

        enviar('1');

    }

    public static void indicarAltaMedica(){

        enviar('2');

    }

    public static void apagar(){

        enviar('0');

    }

    public static void cerrarConexion(){

        if(puerto!=null && puerto.isOpen()){

            puerto.closePort();

        }

    }

}