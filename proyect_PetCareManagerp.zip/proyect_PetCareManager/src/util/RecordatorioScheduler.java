package util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Timer;
import java.util.TimerTask;

public class RecordatorioScheduler {

    public static void iniciar() {
        Timer timer = new Timer(true); // Hilo demonio: no impide que la app se cierre
        TimerTask tarea = new TimerTask() {
            @Override
            public void run() {
                revisarCitasDeManiana();
            }
        };
        // Se ejecuta inmediatamente al iniciar y luego cada 24 horas
        long unDia = 24L * 60 * 60 * 1000;
        timer.scheduleAtFixedRate(tarea, 0, unDia);
    }

    private static void revisarCitasDeManiana() {
        LocalDate manana = LocalDate.now().plusDays(1);
        
        // El JOIN extrae todos los datos que necesitamos en un solo viaje a la base de datos
        String sqlSelect = "SELECT c.id_cita, m.nombre AS mascota, c.fecha, c.hora, c.motivo, p.correo "
                         + "FROM citas c "
                         + "INNER JOIN mascotas m ON c.id_mascota = m.id_mascota "
                         + "INNER JOIN propietarios p ON m.id_propietario = p.id_propietario "
                         + "WHERE c.fecha = ? AND c.estado = 'Pendiente' AND c.recordatorio_enviado = FALSE";

        String sqlUpdate = "UPDATE citas SET recordatorio_enviado = TRUE WHERE id_cita = ?";

        try (Connection cn = ConexionBD.conectar();
             PreparedStatement psSelect = cn.prepareStatement(sqlSelect);
             PreparedStatement psUpdate = cn.prepareStatement(sqlUpdate)) {

            // Buscamos las citas que tengan fecha de mañana
            psSelect.setDate(1, java.sql.Date.valueOf(manana));

            try (ResultSet rs = psSelect.executeQuery()) {
                while (rs.next()) {
                    int idCita = rs.getInt("id_cita");
                    String nombreMascota = rs.getString("mascota");
                    
                    // Formateamos para que el cliente lo lea bien en el correo/WhatsApp
                    String fecha = rs.getDate("fecha").toString(); 
                    // Quitamos los segundos de la hora (ej: 14:30:00 -> 14:30)
                    String hora = rs.getTime("hora").toString().substring(0, 5); 
                    
                    String motivo = rs.getString("motivo");
                    String correo = rs.getString("correo");

                    // 1. Enviar notificaciones
                    if (correo != null && !correo.trim().isEmpty()) {
                        NotificacionService.recordarCitaProxima(correo, nombreMascota, fecha, hora, motivo);
                    }

                    // 2. Marcar la cita en MySQL para no volver a enviar el mensaje
                    psUpdate.setInt(1, idCita);
                    psUpdate.executeUpdate();
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al revisar recordatorios de citas en BD: " + e.getMessage());
        }
    }
}