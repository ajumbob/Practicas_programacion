package util;

/**
 * Punto único desde donde las vistas/controladores disparan las
 * notificaciones automáticas (correo + WhatsApp) sin preocuparse por los
 * detalles de cada canal.
 */
public class NotificacionService {

    public static void notificarVacuna(String correo, String nombreMascota, String nombreVacuna, String fecha) {
        String asunto = "Recordatorio de vacunación - " + nombreMascota;
        String cuerpo = "Estimado propietario,\n\nLe informamos que su mascota " + nombreMascota
                + " ha sido vacunada.\nVacuna aplicada: " + nombreVacuna
                + "\nFecha: " + fecha
                + "\n\nGracias por confiar en nosotros.\nPetCare Manager";
        EmailNotificador.enviar(correo, asunto, cuerpo);

        String msjWpp = "🐾 PetCare: " + nombreMascota + " recibió la vacuna '" + nombreVacuna + "' el " + fecha + ".";
        WhatsAppNotificador.enviar(msjWpp);
    }

    public static void notificarTratamiento(String correo, String nombreMascota, String diagnostico, String tratamiento, String fecha) {
        String asunto = "Notificación de tratamiento médico - " + nombreMascota;
        String cuerpo = "Estimado propietario,\n\nSu mascota " + nombreMascota + " recibió atención médica el " + fecha + ".\n"
                + "Diagnóstico: " + diagnostico + "\n"
                + "Tratamiento indicado: " + tratamiento
                + "\n\nPetCare Manager";
        EmailNotificador.enviar(correo, asunto, cuerpo);

        String msjWpp = "🐾 PetCare: " + nombreMascota + " fue atendido el " + fecha + ". Diagnóstico: " + diagnostico + ".";
        WhatsAppNotificador.enviar(msjWpp);
    }

    public static void notificarInternamiento(String correo, String nombreMascota, String diagnostico) {
        String asunto = "URGENTE: " + nombreMascota + " requiere internamiento";
        String cuerpo = "Estimado propietario,\n\nSu mascota " + nombreMascota + " necesita quedar internada.\n"
                + "Motivo: " + diagnostico
                + "\n\nPor favor comuníquese con la clínica lo antes posible.\nPetCare Manager";
        EmailNotificador.enviar(correo, asunto, cuerpo);

        String msjWpp = "🚨 PetCare: " + nombreMascota + " requiere INTERNAMIENTO. Motivo: " + diagnostico + ". Por favor comuníquese con la clínica.";
        WhatsAppNotificador.enviar(msjWpp);
    }

    public static void notificarCitaAgendada(String correo, String nombreMascota, String fecha, String hora, String motivo) {
        String asunto = "Cita agendada - " + nombreMascota;
        String cuerpo = "Estimado propietario,\n\nSe ha agendado una cita para su mascota " + nombreMascota + ".\n"
                + "Fecha: " + fecha + "\nHora: " + hora + "\nMotivo: " + motivo
                + "\n\nLe recordaremos un día antes.\nPetCare Manager";
        EmailNotificador.enviar(correo, asunto, cuerpo);

        String msjWpp = "🐾 PetCare: cita agendada para " + nombreMascota + " el " + fecha + " a las " + hora + " (" + motivo + ").";
        WhatsAppNotificador.enviar(msjWpp);
    }

    public static void recordarCitaProxima(String correo, String nombreMascota, String fecha, String hora, String motivo) {
        String asunto = "Recordatorio: cita mañana - " + nombreMascota;
        String cuerpo = "Estimado propietario,\n\nLe recordamos que mañana " + fecha + " a las " + hora
                + " tiene una cita programada para su mascota " + nombreMascota + " (" + motivo + ").\n\nPetCare Manager";
        EmailNotificador.enviar(correo, asunto, cuerpo);

        String msjWpp = "⏰ PetCare: recordatorio, mañana " + fecha + " a las " + hora + " tienes cita para " + nombreMascota + " (" + motivo + ").";
        WhatsAppNotificador.enviar(msjWpp);
    }
}
