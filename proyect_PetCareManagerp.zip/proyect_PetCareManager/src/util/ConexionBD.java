package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionBD {

    private static final String URL =
            "jdbc:mysql://localhost:3306/PetCareManager?useSSL=false&serverTimezone=UTC";

    private static final String USUARIO = "admin";

    private static final String PASSWORD = "Azul1993*";

    public static Connection conectar() {

        try {

            return DriverManager.getConnection(URL, USUARIO, PASSWORD);

        } catch (SQLException e) {

            System.out.println("Error de conexión");

            e.printStackTrace();

            return null;

        }

    }

}