package util;

import java.util.Properties;
import jakarta.mail.Message;
import jakarta.mail.MessagingException;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;

/**
 * Envía notificaciones automáticas por correo electrónico usando una
 * cuenta de Gmail y una contraseña de aplicación (JavaMail / jakarta.mail).
 *
 * Se usa para avisar al propietario sobre vacunas, tratamientos y
 * controles médicos de su mascota.
 */
public class EmailNotificador {

    public static boolean enviar(String correoDestino, String asunto, String cuerpo) {
        if (!ConfigNotificaciones.EMAIL_ACTIVO) {
            System.out.println("[EMAIL-SIMULADO] Para: " + correoDestino + " | Asunto: " + asunto + "\n" + cuerpo);
            return true;
        }

        if (correoDestino == null || correoDestino.trim().isEmpty()) {
            System.err.println("No se pudo enviar el correo: el propietario no tiene correo registrado.");
            return false;
        }

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props, new jakarta.mail.Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(ConfigNotificaciones.EMAIL_REMITENTE, ConfigNotificaciones.EMAIL_CLAVE_APP);
            }
        });

        try {
            Message mensaje = new MimeMessage(session);
            mensaje.setFrom(new InternetAddress(ConfigNotificaciones.EMAIL_REMITENTE));
            mensaje.setRecipients(Message.RecipientType.TO, InternetAddress.parse(correoDestino));
            mensaje.setSubject(asunto);
            mensaje.setText(cuerpo);

            Transport.send(mensaje);
            System.out.println("Correo enviado correctamente a " + correoDestino);
            return true;
        } catch (MessagingException e) {
            System.err.println("Error al enviar el correo: " + e.getMessage());
            return false;
        }
    }
}
