package util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * Envía notificaciones por WhatsApp usando el servicio gratuito CallMeBot.
 *
 * Requisitos previos (una sola vez, en el celular que recibirá los mensajes):
 * 1. Agregar el número +34 644 84 71 65 a los contactos de WhatsApp.
 * 2. Enviarle el mensaje: "I allow callmebot to send me messages"
 * 3. CallMeBot responde con un "apikey". Ese valor va en ConfigNotificaciones.
 *
 * Nota: CallMeBot está pensado para notificar a UN número (el tuyo, el de
 * la clínica). No sirve para enviar a cada propietario individualmente a
 * menos que cada uno se registre también en CallMeBot con su propia apikey.
 */
public class WhatsAppNotificador {

    public static boolean enviar(String mensaje) {
        return enviar(ConfigNotificaciones.CALLMEBOT_TELEFONO, mensaje);
    }

    public static boolean enviar(String telefono, String mensaje) {
        if (!ConfigNotificaciones.WHATSAPP_ACTIVO) {
            System.out.println("[WHATSAPP-SIMULADO] Para: " + telefono + " | Mensaje: " + mensaje);
            return true;
        }

        try {
            String textoCodificado = java.net.URLEncoder.encode(mensaje, StandardCharsets.UTF_8);
            String urlTexto = "https://api.callmebot.com/whatsapp.php?phone=" + telefono
                    + "&text=" + textoCodificado
                    + "&apikey=" + ConfigNotificaciones.CALLMEBOT_APIKEY;

            URL url = URI.create(urlTexto).toURL();
            HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
            conexion.setRequestMethod("GET");
            conexion.setConnectTimeout(8000);
            conexion.setReadTimeout(8000);

            int codigo = conexion.getResponseCode();
            BufferedReader br = new BufferedReader(new InputStreamReader(
                    codigo == 200 ? conexion.getInputStream() : conexion.getErrorStream()));
            StringBuilder respuesta = new StringBuilder();
            String linea;
            while ((linea = br.readLine()) != null) respuesta.append(linea);
            br.close();

            System.out.println("Respuesta CallMeBot (" + codigo + "): " + respuesta);
            return codigo == 200;
        } catch (Exception e) {
            System.err.println("Error al enviar WhatsApp: " + e.getMessage());
            return false;
        }
    }
}
