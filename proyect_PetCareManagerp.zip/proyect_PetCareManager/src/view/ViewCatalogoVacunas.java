package view;

import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import controller.CatalogoVacunaController;

public class ViewCatalogoVacunas extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtNombre;
    private JTable tabla;
    private DefaultTableModel modeloTabla;
    private CatalogoVacunaController controller;

    public ViewCatalogoVacunas() {
        controller = new CatalogoVacunaController();

        setTitle("Catálogo de Vacunas - PetCare");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 500, 420);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null);
        setContentPane(contentPane);

        JLabel lblTitulo = new JLabel("Administrar Catálogo de Vacunas");
        lblTitulo.setFont(new Font("Tahoma", Font.BOLD, 14));
        lblTitulo.setBounds(110, 15, 300, 25);
        contentPane.add(lblTitulo);

        JLabel lblNombre = new JLabel("Nueva vacuna:");
        lblNombre.setBounds(10, 60, 90, 25);
        contentPane.add(lblNombre);

        txtNombre = new JTextField();
        txtNombre.setBounds(110, 60, 170, 25);
        contentPane.add(txtNombre);

        JButton btnAgregar = new JButton("Agregar");
        btnAgregar.setBounds(290, 60, 100, 25);
        contentPane.add(btnAgregar);

        JButton btnEliminar = new JButton("Eliminar seleccionada");
        btnEliminar.setBounds(10, 320, 180, 25);
        contentPane.add(btnEliminar);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(10, 100, 460, 210);
        contentPane.add(scrollPane);

        tabla = new JTable();
        modeloTabla = new DefaultTableModel(new Object[][] {}, new String[] { "ID", "Vacuna" });
        tabla.setModel(modeloTabla);
        scrollPane.setViewportView(tabla);

        // ================= EVENTOS =================

        btnAgregar.addActionListener(e -> {
            String nombre = txtNombre.getText().trim();
            if (nombre.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Ingrese el nombre de la vacuna.");
                return;
            }
            String validacion = controller.validarFormato(nombre);
            if (!validacion.equals("OK")) {
                JOptionPane.showMessageDialog(this, validacion, "Error de formato", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (controller.registrarVacunaCatalogo(nombre)) {
                JOptionPane.showMessageDialog(this, "Vacuna registrada con éxito.");
                txtNombre.setText("");
                llenarTabla();
            } else {
                JOptionPane.showMessageDialog(this, "Error al registrar la vacuna.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnEliminar.addActionListener(e -> {
            int fila = tabla.getSelectedRow();
            if (fila == -1) {
                JOptionPane.showMessageDialog(this, "Seleccione una vacuna de la tabla.");
                return;
            }

            try {
                // Convertimos el ID de la primera columna a entero
                int id = Integer.parseInt(modeloTabla.getValueAt(fila, 0).toString());

                int confirmacion = JOptionPane.showConfirmDialog(this, "¿Desea eliminar esta vacuna del catálogo?", "Confirmar", JOptionPane.YES_NO_OPTION);
                if (confirmacion == JOptionPane.YES_OPTION) {
                    if (controller.eliminarVacunaCatalogo(id)) {
                        JOptionPane.showMessageDialog(this, "Vacuna eliminada correctamente.");
                        llenarTabla();
                    } else {
                        JOptionPane.showMessageDialog(this, "No se pudo eliminar la vacuna de la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "El ID de la vacuna no es válido.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        llenarTabla();
        setLocationRelativeTo(null);
    }

    private void llenarTabla() {
        modeloTabla.setRowCount(0);
        for (String[] fila : controller.listar()) {
            if (fila.length == 2) {
                modeloTabla.addRow(fila);
            }
        }
    }

    /** Devuelve solo los nombres, listos para llenar un JComboBox. */
    public static java.util.List<String> obtenerNombres() {
        java.util.List<String> nombres = new java.util.ArrayList<>();
        for (String[] fila : new CatalogoVacunaController().listar()) {
            if (fila.length == 2) nombres.add(fila[1]);
        }
        return nombres;
    }
}