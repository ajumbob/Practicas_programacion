package view;

import java.awt.Color;
import java.awt.Font;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import controller.VacunaController;
import dao.HistorialVacunaDAO;
import dao.MascotaDAO;
import dao.PropietarioDAO;
import dao.VacunaDAO;
import model.Propietario;
import model.Vacuna;
import util.NotificacionService;

public class ViewVacunas extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtBuscar;
    private JLabel lblValorNombre, lblValorEspecie, lblValorEdad;
    
    private JComboBox<Vacuna> cbNombreVacuna;
    private JTextField txtFecha, txtObservacion;
    private JTable tablaVacunas;
    private DefaultTableModel modeloTabla;
    
    private VacunaController controller;
    private int idMascotaSeleccionada = -1;
    private String correoDueno = "";

    public ViewVacunas() {
        controller = new VacunaController();

        setTitle("Actualización de Vacunas - PetCare");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 650, 550);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null);
        setContentPane(contentPane);

        JLabel lblTitulo = new JLabel("Actualizar Vacunas");
        lblTitulo.setFont(new Font("Tahoma", Font.BOLD, 14));
        lblTitulo.setBounds(250, 10, 200, 25);
        contentPane.add(lblTitulo);

        // ================= PASO 1: BUSCAR MASCOTA =================
        JLabel lblBuscar = new JLabel("Buscar Mascota (ID o Nombre):");
        lblBuscar.setBounds(20, 50, 180, 25);
        contentPane.add(lblBuscar);

        txtBuscar = new JTextField();
        txtBuscar.setBounds(200, 50, 120, 25);
        contentPane.add(txtBuscar);

        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(330, 50, 80, 25);
        contentPane.add(btnBuscar);

        // ================= MOSTRAR DATOS DE MASCOTA =================
        JPanel panelDatos = new JPanel();
        panelDatos.setBounds(20, 90, 590, 40);
        panelDatos.setBackground(new Color(240, 248, 255));
        panelDatos.setLayout(null);
        contentPane.add(panelDatos);

        lblValorNombre = new JLabel("-");
        lblValorNombre.setFont(new Font("Tahoma", Font.BOLD, 12));
        lblValorNombre.setBounds(10, 10, 150, 20);
        panelDatos.add(lblValorNombre);

        lblValorEspecie = new JLabel("-");
        lblValorEspecie.setFont(new Font("Tahoma", Font.BOLD, 12));
        lblValorEspecie.setBounds(200, 10, 150, 20);
        panelDatos.add(lblValorEspecie);

        // Como usamos fechaNacimiento, calcularemos la edad o mostraremos la fecha
        lblValorEdad = new JLabel("-"); 
        lblValorEdad.setFont(new Font("Tahoma", Font.BOLD, 12));
        lblValorEdad.setBounds(400, 10, 150, 20);
        panelDatos.add(lblValorEdad);

        // ================= TABLA DE VACUNAS EXISTENTES =================
        JLabel lblSubtituloTabla = new JLabel("Vacunas Aplicadas:");
        lblSubtituloTabla.setFont(new Font("Tahoma", Font.BOLD, 12));
        lblSubtituloTabla.setBounds(20, 150, 200, 20);
        contentPane.add(lblSubtituloTabla);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(20, 180, 590, 150);
        contentPane.add(scrollPane);

        tablaVacunas = new JTable();
        modeloTabla = new DefaultTableModel(
            new Object[][] {},
            new String[] { "Vacuna", "Fecha Aplicación" }
        );
        tablaVacunas.setModel(modeloTabla);
        scrollPane.setViewportView(tablaVacunas);

        // ================= FORMULARIO PARA AGREGAR VACUNA =================
        JLabel lblSubtituloForm = new JLabel("Registrar Nueva Vacuna:");
        lblSubtituloForm.setFont(new Font("Tahoma", Font.BOLD, 12));
        lblSubtituloForm.setBounds(20, 350, 200, 20);
        contentPane.add(lblSubtituloForm);

        JLabel lblVacuna = new JLabel("Nombre Vacuna:");
        lblVacuna.setBounds(20, 380, 100, 25);
        contentPane.add(lblVacuna);

        cbNombreVacuna = new JComboBox<>();
        cbNombreVacuna.setBounds(120, 380, 150, 25);
        cargarCatalogoVacunas();
        contentPane.add(cbNombreVacuna);

        JLabel lblFecha = new JLabel("Fecha:");
        lblFecha.setBounds(290, 380, 50, 25);
        contentPane.add(lblFecha);

        txtFecha = new JTextField();
        txtFecha.setBounds(340, 380, 100, 25);
        txtFecha.setToolTipText("DD/MM/AAAA");
        contentPane.add(txtFecha);

        JLabel lblObs = new JLabel("Observación:");
        lblObs.setBounds(20, 420, 100, 25);
        contentPane.add(lblObs);

        txtObservacion = new JTextField();
        txtObservacion.setBounds(120, 420, 320, 25);
        contentPane.add(txtObservacion);

        JButton btnAgregar = new JButton("Agregar Vacuna");
        btnAgregar.setBounds(460, 380, 150, 65);
        contentPane.add(btnAgregar);

        // ================= EVENTOS =================

        btnBuscar.addActionListener(e -> {
            String termino = txtBuscar.getText().trim();
            if (termino.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Ingrese un ID o Nombre para buscar.");
                return;
            }

            boolean encontrada = false;
            MascotaDAO mascotaDao = new MascotaDAO();
            List<String[]> mascotas = mascotaDao.listarConDetalles();
            
            for (String[] m : mascotas) {
                if (m[0].equalsIgnoreCase(termino) || m[1].equalsIgnoreCase(termino)) {
                    idMascotaSeleccionada = Integer.parseInt(m[0]);
                    lblValorNombre.setText(m[1]);
                    lblValorEspecie.setText(m[2]);
                    lblValorEdad.setText("Nacimiento: " + m[4]); 
                    
                    // Buscar el correo del dueño para las notificaciones
                    PropietarioDAO pDao = new PropietarioDAO();
                    for (Propietario p : pDao.listarTodos()) {
                        if ((p.getNombres() + " " + p.getApellidos()).equals(m[6])) {
                            correoDueno = p.getCorreo();
                            break;
                        }
                    }
                    
                    encontrada = true;
                    cargarTablaVacunas();
                    break;
                }
            }

            if (!encontrada) {
                JOptionPane.showMessageDialog(this, "Mascota no encontrada en BD.");
                idMascotaSeleccionada = -1;
                lblValorNombre.setText("-");
                lblValorEspecie.setText("-");
                lblValorEdad.setText("-");
                modeloTabla.setRowCount(0);
                correoDueno = "";
            }
        });

        btnAgregar.addActionListener(e -> {
            if (idMascotaSeleccionada == -1) {
                JOptionPane.showMessageDialog(this, "Primero debe buscar y seleccionar una mascota.");
                return;
            }

            Vacuna vacunaObj = (Vacuna) cbNombreVacuna.getSelectedItem();
            if (vacunaObj == null) {
                JOptionPane.showMessageDialog(this, "Debe registrar vacunas en el catálogo primero.");
                return;
            }

            String fecha = txtFecha.getText().trim();
            
            String validacion = controller.validarFormatos(fecha);
            if (!validacion.equals("OK")) {
                JOptionPane.showMessageDialog(this, validacion, "Error de formato", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int idVacuna = vacunaObj.getIdVacuna();

            if (controller.registrarVacuna(idMascotaSeleccionada, idVacuna, fecha)) {
                JOptionPane.showMessageDialog(this, "Vacuna registrada con éxito.");
                
                if (!correoDueno.isEmpty()) {
                    NotificacionService.notificarVacuna(correoDueno, lblValorNombre.getText(), vacunaObj.getNombre(), fecha);
                }
                
                txtFecha.setText("");
                txtObservacion.setText("");
                cargarTablaVacunas(); 
            } else {
                JOptionPane.showMessageDialog(this, "Error al registrar la vacuna.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        setLocationRelativeTo(null);
    }

    private void cargarCatalogoVacunas() {
        cbNombreVacuna.removeAllItems();
        VacunaDAO vDao = new VacunaDAO();
        List<Vacuna> lista = vDao.listarTodos();
        for (Vacuna v : lista) {
            cbNombreVacuna.addItem(v); // Sobreescribe toString() en Vacuna para que muestre el nombre
        }
    }

    private void cargarTablaVacunas() {
        modeloTabla.setRowCount(0);
        if (idMascotaSeleccionada == -1) return;

        HistorialVacunaDAO hvDao = new HistorialVacunaDAO();
        List<String[]> historial = hvDao.listarPorMascota(idMascotaSeleccionada);
        
        for (String[] fila : historial) {
            modeloTabla.addRow(fila);
        }
    }
}