package view;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import controller.AtencionController;
import dao.CitaDAO;
import util.ArduinoController;
import util.NotificacionService;

public class ViewAtenciones extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtBuscarCita, txtMascotaNombre, txtFecha;
    private JTextField txtDiagnostico, txtTratamiento, txtObservacion;
    private JCheckBox chkInternamiento;

    private AtencionController controller;
    
    // Variables para guardar los datos cruzados que trae el DAO
    private int idCitaCargada = -1;
    private String correoDueno = "";
    private String telefonoDueno = "";

    public ViewAtenciones() {
        controller = new AtencionController();

        setTitle("Registrar Atención Médica - PetCare");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 550, 480);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null);
        setContentPane(contentPane);

        JLabel lblTitulo = new JLabel("Registrar Atención Médica");
        lblTitulo.setFont(new Font("Tahoma", Font.BOLD, 14));
        lblTitulo.setBounds(180, 15, 250, 25);
        contentPane.add(lblTitulo);

        // ================= PASO 1: BUSCAR CITA =================
        JLabel lblBuscar = new JLabel("ID Cita (Solo número):");
        lblBuscar.setBounds(20, 60, 150, 25);
        contentPane.add(lblBuscar);

        txtBuscarCita = new JTextField();
        txtBuscarCita.setBounds(160, 60, 120, 25);
        contentPane.add(txtBuscarCita);

        JButton btnBuscar = new JButton("Buscar Turno");
        btnBuscar.setBounds(290, 60, 120, 25);
        contentPane.add(btnBuscar);

        // ================= DATOS EXTRAÍDOS (SOLO LECTURA) =================
        JLabel lblMascota = new JLabel("Paciente:");
        lblMascota.setBounds(20, 110, 80, 25);
        contentPane.add(lblMascota);

        txtMascotaNombre = new JTextField();
        txtMascotaNombre.setBounds(100, 110, 150, 25);
        txtMascotaNombre.setEditable(false);
        txtMascotaNombre.setBackground(Color.LIGHT_GRAY);
        contentPane.add(txtMascotaNombre);

        JLabel lblFecha = new JLabel("Fecha:");
        lblFecha.setBounds(280, 110, 50, 25);
        contentPane.add(lblFecha);

        txtFecha = new JTextField();
        txtFecha.setBounds(330, 110, 100, 25);
        txtFecha.setEditable(false);
        txtFecha.setBackground(Color.LIGHT_GRAY);
        contentPane.add(txtFecha);

        // ================= DATOS CLÍNICOS =================
        JLabel lblClinicos = new JLabel("Datos Clínicos:");
        lblClinicos.setFont(new Font("Tahoma", Font.BOLD, 12));
        lblClinicos.setBounds(20, 160, 150, 20);
        contentPane.add(lblClinicos);

        JLabel lblDiag = new JLabel("Diagnóstico:");
        lblDiag.setBounds(20, 190, 80, 25);
        contentPane.add(lblDiag);

        txtDiagnostico = new JTextField();
        txtDiagnostico.setBounds(100, 190, 380, 25);
        contentPane.add(txtDiagnostico);

        JLabel lblTrat = new JLabel("Tratamiento:");
        lblTrat.setBounds(20, 230, 80, 25);
        contentPane.add(lblTrat);

        txtTratamiento = new JTextField();
        txtTratamiento.setBounds(100, 230, 380, 25);
        contentPane.add(txtTratamiento);

        JLabel lblObs = new JLabel("Observación:");
        lblObs.setBounds(20, 270, 80, 25);
        contentPane.add(lblObs);

        txtObservacion = new JTextField();
        txtObservacion.setBounds(100, 270, 380, 25);
        contentPane.add(txtObservacion);

        // ================= INTERNAMIENTO (Arduino: LED rojo) =================
        chkInternamiento = new JCheckBox("¿Requiere internamiento?");
        chkInternamiento.setFont(new Font("Tahoma", Font.BOLD, 12));
        chkInternamiento.setForeground(new Color(180, 0, 0));
        chkInternamiento.setBounds(100, 310, 250, 25);
        contentPane.add(chkInternamiento);

        // ================= BOTÓN DE REGISTRO =================
        JButton btnRegistrar = new JButton("Guardar Atención Médica");
        btnRegistrar.setBounds(150, 360, 220, 35);
        contentPane.add(btnRegistrar);

        // ================= EVENTOS =================
        btnBuscar.addActionListener(e -> {
            try {
                int idCitaBuscada = Integer.parseInt(txtBuscarCita.getText().trim());
                CitaDAO citaDao = new CitaDAO();
                String[] datos = citaDao.buscarCitaPorId(idCitaBuscada);
                
                if (datos != null) {
                    idCitaCargada = Integer.parseInt(datos[0]);
                    txtFecha.setText(datos[1]);
                    txtMascotaNombre.setText(datos[3]);
                    correoDueno = datos[4];
                    telefonoDueno = datos[5]; // Listo para WhatsAppNotificador
                } else {
                    JOptionPane.showMessageDialog(this, "No se encontró una cita con ese ID.", "Error", JOptionPane.ERROR_MESSAGE);
                    limpiarTodo();
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "El ID de la cita debe ser un número entero.");
            }
        });

        btnRegistrar.addActionListener(e -> {
            if (idCitaCargada == -1) {
                JOptionPane.showMessageDialog(this, "Debe buscar un turno válido primero.");
                return;
            }

            String diag = txtDiagnostico.getText().trim();
            String trat = txtTratamiento.getText().trim();
            String obs = txtObservacion.getText().trim();
            String fecha = txtFecha.getText();
            boolean internar = chkInternamiento.isSelected();

            if (diag.isEmpty() || trat.isEmpty() || obs.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Todos los campos médicos son obligatorios.", "Campos vacíos", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // Usamos tu validación Regex original (pasando "1" temporal a peso/temp si los quitaste)
            String validacion = controller.validarFormatos("1", "10", diag, trat, obs);
            if (!validacion.equals("OK")) {
                JOptionPane.showMessageDialog(this, validacion, "Error de formato", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (controller.registrarAtencion(idCitaCargada, fecha, diag, trat, obs, internar)) {
                
                // Hardware: Arduino
                if (internar) {
                    ArduinoController.indicarInternamiento();
                } else {
                    ArduinoController.indicarAltaMedica();
                }

                // Software: WhatsApp / Email
                if (internar) {
                    NotificacionService.notificarInternamiento(correoDueno, txtMascotaNombre.getText(), diag);
                } else {
                    NotificacionService.notificarTratamiento(correoDueno, txtMascotaNombre.getText(), diag, trat, fecha);
                }

                JOptionPane.showMessageDialog(this, "Atención guardada. Se ha notificado al propietario.");
                limpiarTodo();
            }
        });

        setLocationRelativeTo(null);
    }

    private void limpiarTodo() {
        txtBuscarCita.setText("");
        idCitaCargada = -1;
        correoDueno = "";
        telefonoDueno = "";
        txtMascotaNombre.setText("");
        txtFecha.setText("");
        txtDiagnostico.setText("");
        txtTratamiento.setText("");
        txtObservacion.setText("");
        chkInternamiento.setSelected(false);
    }
}