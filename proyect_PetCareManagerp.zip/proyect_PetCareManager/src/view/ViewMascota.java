package view;

import java.awt.Color;
import java.awt.Font;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import controller.MascotaController;
import dao.EspecieDAO;
import dao.MascotaDAO;
import dao.PropietarioDAO;
import dao.RazaDAO;
import model.Especie;
import model.Propietario;
import model.Raza;

public class ViewMascota extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtNombre, txtFechaNac, txtColor, txtPeso;
    
    // Aquí están los JComboBox tipados con tus objetos reales
    private JComboBox<Especie> cbEspecie;
    private JComboBox<Raza> cbRaza;
    private JComboBox<String> cbSexo;
    
    private JTable tablaMascotas;
    private DefaultTableModel modeloTabla;
    private MascotaController controller;

    private JTextField txtBuscarPropietario;
    private JTextField txtPropietarioSeleccionado;
    
    // Ahora guardamos el ID numérico del dueño, no su cédula en texto
    private int idPropietarioSeleccionado = -1;
    private JTextField txtFiltro;

    public ViewMascota() {
        controller = new MascotaController();

        setTitle("Registro de Mascotas - PetCare");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 900, 520); // Aumenté el alto para que entren los nuevos campos

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null);
        setContentPane(contentPane);

        JLabel lblTitulo = new JLabel("Registro de Mascotas");
        lblTitulo.setFont(new Font("Tahoma", Font.BOLD, 14));
        lblTitulo.setBounds(370, 15, 250, 25);
        contentPane.add(lblTitulo);

        // ================= BUSCAR / SELECCIONAR PROPIETARIO =================
        crearLabel(10, 55, "Buscar Propietario (Cédula o Nombre):", 230);
        txtBuscarPropietario = crearTextField(10, 78, 150);

        JButton btnBuscarProp = new JButton("Buscar");
        btnBuscarProp.setBounds(165, 78, 85, 25);
        contentPane.add(btnBuscarProp);

        crearLabel(10, 108, "Propietario:", 80);
        txtPropietarioSeleccionado = crearTextField(100, 108, 150);
        txtPropietarioSeleccionado.setEditable(false);
        txtPropietarioSeleccionado.setBackground(Color.LIGHT_GRAY);

        // ================= FORMULARIO MASCOTA =================
        // El ID ya no se pide, MySQL lo autogenera
        crearLabel(10, 145, "Nombre:", 80);
        txtNombre = crearTextField(100, 145, 150);

        crearLabel(10, 180, "Especie:", 80);
        cbEspecie = new JComboBox<>();
        cbEspecie.setBounds(100, 180, 150, 25);
        contentPane.add(cbEspecie);

        crearLabel(10, 215, "Raza:", 80);
        cbRaza = new JComboBox<>();
        cbRaza.setBounds(100, 215, 150, 25);
        contentPane.add(cbRaza);

        crearLabel(10, 250, "F. Nacimiento:", 90);
        txtFechaNac = crearTextField(100, 250, 80);
        crearLabel(185, 250, "(AAAA-MM-DD)", 80).setForeground(Color.GRAY);

        crearLabel(10, 285, "Color:", 80);
        txtColor = crearTextField(100, 285, 150);
        
        crearLabel(10, 320, "Peso (Kg):", 80);
        txtPeso = crearTextField(100, 320, 80);

        crearLabel(10, 355, "Sexo:", 80);
        cbSexo = new JComboBox<>(new String[]{"Macho", "Hembra"});
        cbSexo.setBounds(100, 355, 150, 25);
        contentPane.add(cbSexo);

        JButton btnGuardar = new JButton("Registrar");
        btnGuardar.setBounds(10, 400, 100, 30);
        contentPane.add(btnGuardar);

        // ================= TABLA Y FILTROS =================
        crearLabel(280, 55, "Buscar en la tabla (ID o Nombre):", 220);
        txtFiltro = crearTextField(280, 78, 200);

        JButton btnFiltrar = new JButton("Filtrar");
        btnFiltrar.setBounds(485, 78, 85, 25);
        contentPane.add(btnFiltrar);

        JButton btnLimpiarFiltro = new JButton("Mostrar todo");
        btnLimpiarFiltro.setBounds(575, 78, 110, 25);
        contentPane.add(btnLimpiarFiltro);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(280, 110, 590, 320);
        contentPane.add(scrollPane);

        tablaMascotas = new JTable();
        modeloTabla = new DefaultTableModel(
            new Object[][] {},
            new String[] { "ID", "Nombre", "Especie", "Raza", "Fecha Nac.", "Sexo", "Dueño" }
        );
        tablaMascotas.setModel(modeloTabla);
        scrollPane.setViewportView(tablaMascotas);

        // ================= EVENTOS =================

        // 1. Cargar datos iniciales
        cargarEspecies();
        llenarTabla();

        // 2. Al cambiar la especie, cargar sus razas correspondientes
        cbEspecie.addActionListener(e -> {
            Especie espSeleccionada = (Especie) cbEspecie.getSelectedItem();
            if (espSeleccionada != null) {
                cargarRazas(espSeleccionada.getIdEspecie());
            }
        });

        // 3. Buscar Propietario en la BD
        btnBuscarProp.addActionListener(e -> {
            String termino = txtBuscarPropietario.getText().trim();
            if (termino.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Ingrese cédula o nombre.");
                return;
            }
            
            // Reemplaza esto con tu llamada real a PropietarioDAO
            PropietarioDAO pDao = new PropietarioDAO();
            List<Propietario> dueños = pDao.listarTodos(); 
            boolean encontrado = false;
            
            for (Propietario p : dueños) {
                if (p.getCedula().equals(termino) || p.getNombres().contains(termino)) {
                    idPropietarioSeleccionado = p.getIdPropietario(); // Guardamos el ID real de SQL
                    txtPropietarioSeleccionado.setText(p.getNombres() + " " + p.getApellidos());
                    encontrado = true;
                    break;
                }
            }
            
            if (!encontrado) {
                JOptionPane.showMessageDialog(this, "Propietario no encontrado.");
                idPropietarioSeleccionado = -1;
                txtPropietarioSeleccionado.setText("");
            }
        });

        // 4. Guardar Mascota
        btnGuardar.addActionListener(e -> {
            if (idPropietarioSeleccionado == -1) {
                JOptionPane.showMessageDialog(this, "Debe buscar y seleccionar un Propietario.");
                return;
            }
            if (cbEspecie.getSelectedItem() == null || cbRaza.getSelectedItem() == null) {
                JOptionPane.showMessageDialog(this, "Debe seleccionar una Especie y una Raza.");
                return;
            }

            try {
                String nombre = txtNombre.getText().trim();
                String sexo = cbSexo.getSelectedItem().toString();
                String color = txtColor.getText().trim();
                double peso = Double.parseDouble(txtPeso.getText().trim());
                
                // Convertir texto a LocalDate
                LocalDate fechaNac = LocalDate.parse(txtFechaNac.getText().trim(), DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                
                // ¡AQUÍ ESTÁ LA MAGIA! Recuperamos los objetos enteros del ComboBox
                Especie especieObj = (Especie) cbEspecie.getSelectedItem();
                Raza razaObj = (Raza) cbRaza.getSelectedItem();
                
                // Extraemos los IDs para mandarlos al controlador
                int idEspecie = especieObj.getIdEspecie();
                int idRaza = razaObj.getIdRaza();

                // Llamamos al controlador actualizado
                if (controller.registrarMascota(nombre, sexo, fechaNac, color, peso, idPropietarioSeleccionado, idEspecie, idRaza)) {
                    JOptionPane.showMessageDialog(this, "Mascota registrada con éxito.");
                    limpiarFormulario();
                    llenarTabla();
                }
                
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error en los datos. Revise que el peso sea numérico y la fecha tenga formato AAAA-MM-DD.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        setLocationRelativeTo(null);
    }

    // ================= MÉTODOS DE APOYO =================
    
    private JLabel crearLabel(int x, int y, String texto, int width) {
        JLabel label = new JLabel(texto);
        label.setBounds(x, y, width, 25);
        contentPane.add(label);
        return label;
    }

    private JTextField crearTextField(int x, int y, int width) {
        JTextField textField = new JTextField();
        textField.setBounds(x, y, width, 25);
        contentPane.add(textField);
        return textField;
    }

    private void cargarEspecies() {
    	cbEspecie.removeAllItems();
        
        // Instanciamos el DAO y pedimos la lista de especies a MySQL
        EspecieDAO dao = new EspecieDAO();
        List<Especie> lista = dao.listarTodos();
        
        for (Especie e : lista) {
            cbEspecie.addItem(e); 
        }
    }

    private void cargarRazas(int idEspecie) {
    	cbRaza.removeAllItems();
        
        // Instanciamos el DAO y pedimos las razas filtradas por la especie seleccionada
        RazaDAO dao = new RazaDAO();
        List<Raza> lista = dao.listarPorEspecie(idEspecie);
        
        for (Raza r : lista) {
            cbRaza.addItem(r);
        }
    }

    private void llenarTabla() {
        modeloTabla.setRowCount(0);
        
        // Traemos los datos desde MySQL usando tu DAO
        MascotaDAO daoMascota = new MascotaDAO();
        List<String[]> lista = daoMascota.listarConDetalles();
        
        // Dibujamos cada fila en la tabla de la interfaz
        for (String[] fila : lista) {
            modeloTabla.addRow(fila);
        }
    }
    
    private void limpiarFormulario() {
        txtNombre.setText("");
        txtFechaNac.setText("");
        txtColor.setText("");
        txtPeso.setText("");
    }
}