package view;

import java.awt.Font;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import controller.PropietarioController;
import dao.PropietarioDAO;
import model.Propietario;

public class ViewPropietarios extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtCedula, txtNombres, txtApellidos, txtTelefono, txtDireccion, txtCorreo;
    private JTable tablaPropietarios;
    private DefaultTableModel modeloTabla;
    private PropietarioController controller;

    public ViewPropietarios() {
        controller = new PropietarioController();

        setTitle("Registro de Dueños / Clientes - PetCare");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 750, 460);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null);
        setContentPane(contentPane);

        JLabel lblTitulo = new JLabel("Registro de Dueños / Clientes");
        lblTitulo.setFont(new Font("Tahoma", Font.BOLD, 14));
        lblTitulo.setBounds(250, 15, 250, 25);
        contentPane.add(lblTitulo);

        // ================= FORMULARIO =================
        crearLabel(10, 65, "Cédula:");
        txtCedula = crearTextField(100, 65);
        
        crearLabel(10, 105, "Nombres:");
        txtNombres = crearTextField(100, 105);
        
        crearLabel(10, 145, "Apellidos:");
        txtApellidos = crearTextField(100, 145);
        
        crearLabel(10, 185, "Teléfono:");
        txtTelefono = crearTextField(100, 185);
        
        crearLabel(10, 225, "Dirección:");
        txtDireccion = crearTextField(100, 225);
        
        crearLabel(10, 265, "Correo:");
        txtCorreo = crearTextField(100, 265);

        JButton btnGuardar = new JButton("Registrar");
        btnGuardar.setBounds(10, 310, 110, 30);
        contentPane.add(btnGuardar);

        // ================= TABLA =================
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(280, 65, 430, 280);
        contentPane.add(scrollPane);

        tablaPropietarios = new JTable();
        modeloTabla = new DefaultTableModel(
            new Object[][] {},
            new String[] { "ID", "Cédula", "Nombres", "Apellidos", "Teléfono", "Correo" }
        );
        tablaPropietarios.setModel(modeloTabla);
        scrollPane.setViewportView(tablaPropietarios);

        // ================= EVENTOS =================
        btnGuardar.addActionListener(e -> {
            String cedula = txtCedula.getText().trim();
            String nombres = txtNombres.getText().trim();
            String apellidos = txtApellidos.getText().trim();
            String telefono = txtTelefono.getText().trim();
            String direccion = txtDireccion.getText().trim();
            String correo = txtCorreo.getText().trim();

            if (cedula.isEmpty() || nombres.isEmpty() || apellidos.isEmpty() || telefono.isEmpty() || direccion.isEmpty() || correo.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios.", "Campos vacíos", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // Nota: Debes asegurarte de que tu PropietarioController reciba ahora nombres y apellidos por separado
            if (controller.registrarPropietario(cedula, nombres, apellidos, telefono, direccion, correo)) {
                JOptionPane.showMessageDialog(this, "Propietario registrado con éxito.");
                limpiarCampos();
                llenarTabla();
            } else {
                JOptionPane.showMessageDialog(this, "Ocurrió un error o el formato no es válido.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        llenarTabla();
        setLocationRelativeTo(null);
    }

    // ================= MÉTODOS DE APOYO =================
    private void crearLabel(int x, int y, String texto) {
        JLabel label = new JLabel(texto);
        label.setBounds(x, y, 80, 25);
        contentPane.add(label);
    }

    private JTextField crearTextField(int x, int y) {
        JTextField textField = new JTextField();
        textField.setBounds(x, y, 150, 25);
        contentPane.add(textField);
        return textField;
    }
    
    private void limpiarCampos() {
        txtCedula.setText("");
        txtNombres.setText("");
        txtApellidos.setText("");
        txtTelefono.setText("");
        txtDireccion.setText("");
        txtCorreo.setText("");
    }

    private void llenarTabla() {
        modeloTabla.setRowCount(0);
        PropietarioDAO dao = new PropietarioDAO();
        List<Propietario> lista = dao.listarTodos();
        
        for (Propietario p : lista) {
            modeloTabla.addRow(new Object[] {
                p.getIdPropietario(),
                p.getCedula(),
                p.getNombres(),
                p.getApellidos(),
                p.getTelefono(),
                p.getCorreo()
            });
        }
    }
}