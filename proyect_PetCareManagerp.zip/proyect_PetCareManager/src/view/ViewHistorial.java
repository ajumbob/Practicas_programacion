package view;

import java.awt.Color;
import java.awt.Font;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class ViewHistorial extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtBuscar;
    private JLabel lblValorMascota, lblValorDueno, lblValorEspecie;
    private JTextArea txtAreaHistorial;

    public ViewHistorial() {
        setTitle("Historial Médico - PetCare");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 450, 500);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null);
        setContentPane(contentPane);

        JLabel lblTitulo = new JLabel("Consultar Historial Médico");
        lblTitulo.setFont(new Font("Tahoma", Font.BOLD, 14));
        lblTitulo.setBounds(120, 15, 250, 25);
        contentPane.add(lblTitulo);

        // ================= BUSCADOR =================
        JLabel lblBuscar = new JLabel("Buscar (ID o Nombre):");
        lblBuscar.setBounds(20, 60, 150, 25);
        contentPane.add(lblBuscar);

        txtBuscar = new JTextField();
        txtBuscar.setBounds(160, 60, 120, 25);
        contentPane.add(txtBuscar);

        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(290, 60, 90, 25);
        contentPane.add(btnBuscar);

        // ================= DATOS DE LA MASCOTA =================
        JLabel lblMascota = new JLabel("Mascota:");
        lblMascota.setBounds(20, 100, 60, 25);
        contentPane.add(lblMascota);
        
        lblValorMascota = new JLabel("-");
        lblValorMascota.setFont(new Font("Tahoma", Font.BOLD, 12));
        lblValorMascota.setBounds(80, 100, 250, 25);
        contentPane.add(lblValorMascota);

        JLabel lblDueno = new JLabel("Dueño:");
        lblDueno.setBounds(20, 125, 60, 25);
        contentPane.add(lblDueno);
        
        lblValorDueno = new JLabel("-");
        lblValorDueno.setFont(new Font("Tahoma", Font.BOLD, 12));
        lblValorDueno.setBounds(80, 125, 250, 25);
        contentPane.add(lblValorDueno);

        JLabel lblEspecie = new JLabel("Especie:");
        lblEspecie.setBounds(20, 150, 60, 25);
        contentPane.add(lblEspecie);
        
        lblValorEspecie = new JLabel("-");
        lblValorEspecie.setFont(new Font("Tahoma", Font.BOLD, 12));
        lblValorEspecie.setBounds(80, 150, 250, 25);
        contentPane.add(lblValorEspecie);

        // ================= TEXTAREA DEL HISTORIAL =================
        JLabel lblHistorial = new JLabel("Historial:");
        lblHistorial.setBounds(20, 190, 80, 25);
        contentPane.add(lblHistorial);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(20, 220, 390, 220);
        contentPane.add(scrollPane);

        txtAreaHistorial = new JTextArea();
        txtAreaHistorial.setEditable(false); // Solo lectura
        txtAreaHistorial.setFont(new Font("Monospaced", Font.PLAIN, 12));
        txtAreaHistorial.setBackground(new Color(245, 245, 245));
        scrollPane.setViewportView(txtAreaHistorial);

        // ================= EVENTOS =================
        btnBuscar.addActionListener(e -> {
            String termino = txtBuscar.getText().trim();
            if (termino.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Ingrese un ID o Nombre.");
                return;
            }

            boolean encontrada = false;
            
            // Llamamos a MySQL usando el DAO
            dao.MascotaDAO mascotaDao = new dao.MascotaDAO();
            List<String[]> mascotas = mascotaDao.listarConDetalles();
            
            for (String[] m : mascotas) {
                // m[0] es el ID, m[1] es el nombre
                if (m[0].equalsIgnoreCase(termino) || m[1].equalsIgnoreCase(termino)) {
                    
                    // Actualizamos las variables correctas (lblValor...)
                    lblValorMascota.setText(m[1]);
                    lblValorEspecie.setText(m[2]);
                    lblValorDueno.setText(m[6]); 
                    
                    // Ejecutamos la carga del historial en el TextArea
                    int idMascota = Integer.parseInt(m[0]);
                    cargarHistorial(idMascota);
                    
                    encontrada = true;
                    break;
                }
            }

            if (!encontrada) {
                JOptionPane.showMessageDialog(this, "Mascota no encontrada en la base de datos.");
                lblValorMascota.setText("-");
                lblValorDueno.setText("-");
                lblValorEspecie.setText("-");
                txtAreaHistorial.setText("");
            }
        });
        
        setLocationRelativeTo(null);
    }

    // ================= MÉTODO PARA DIBUJAR EL HISTORIAL DE MYSQL =================
    private void cargarHistorial(int idMascota) {
        controller.AtencionController atencionCtrl = new controller.AtencionController();
        List<String[]> atenciones = atencionCtrl.obtenerHistorialMedico(idMascota);
        
        StringBuilder sb = new StringBuilder();
        
        if (atenciones.isEmpty()) {
            sb.append("No hay atenciones médicas registradas para este paciente.\n");
        } else {
            for (String[] a : atenciones) {
                sb.append("--------------------------------\n");
                sb.append("Fecha: ").append(a[1]).append("\n\n"); 
                sb.append("Diagnóstico:\n").append(a[2]).append("\n\n"); 
                sb.append("Tratamiento:\n").append(a[3]).append("\n\n");
                sb.append("Observaciones:\n").append(a[4]).append("\n");
            }
            sb.append("--------------------------------\n");
        }
        
        txtAreaHistorial.setText(sb.toString());
        txtAreaHistorial.setCaretPosition(0); 
    }
}