package view;

import java.awt.Color;
import java.awt.Font;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import controller.CitaController;
import dao.CitaDAO;
import dao.MascotaDAO;
import util.NotificacionService;

public class ViewCitas extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtBuscar;
    private JTextField txtMascota, txtPropietario;
    private JTextField txtFecha, txtHora;
    private JComboBox<String> cbMotivo;
    private JTable tablaCitas;
    private DefaultTableModel modeloTabla;
    private CitaController controller;
    
    // Ahora guardamos el ID como entero para MySQL
    private int idMascotaSeleccionada = -1;
    // Guardamos el correo y teléfono temporalmente para las notificaciones
    private String correoDueno = "";
    private String telefonoDueno = "";

    public ViewCitas() {
        controller = new CitaController();

        setTitle("Agenda Médica - PetCare");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 780, 480);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null);
        setContentPane(contentPane);

        JLabel lblTitulo = new JLabel("Planificación de Turnos");
        lblTitulo.setFont(new Font("Tahoma", Font.BOLD, 14));
        lblTitulo.setBounds(280, 10, 250, 25);
        contentPane.add(lblTitulo);

        // ================= PASO 1: BUSCAR MASCOTA =================
        JLabel lblPaso1 = new JLabel("Paso 1: Buscar Mascota (ID o Nombre)");
        lblPaso1.setFont(new Font("Tahoma", Font.BOLD, 11));
        lblPaso1.setBounds(10, 45, 250, 20);
        contentPane.add(lblPaso1);

        txtBuscar = new JTextField();
        txtBuscar.setBounds(10, 70, 150, 25);
        contentPane.add(txtBuscar);

        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(170, 70, 80, 25);
        contentPane.add(btnBuscar);

        // ================= PASO 2: DATOS ENCONTRADOS =================
        JLabel lblMascota = new JLabel("Mascota:");
        lblMascota.setBounds(10, 110, 80, 25);
        contentPane.add(lblMascota);

        txtMascota = new JTextField();
        txtMascota.setBounds(100, 110, 150, 25);
        txtMascota.setEditable(false); 
        txtMascota.setBackground(Color.LIGHT_GRAY);
        contentPane.add(txtMascota);

        JLabel lblPropietario = new JLabel("Dueño:");
        lblPropietario.setBounds(10, 140, 80, 25);
        contentPane.add(lblPropietario);

        txtPropietario = new JTextField();
        txtPropietario.setBounds(100, 140, 150, 25);
        txtPropietario.setEditable(false); 
        txtPropietario.setBackground(Color.LIGHT_GRAY);
        contentPane.add(txtPropietario);

        // ================= PASO 3: INGRESAR DATOS CITA =================
        JLabel lblFecha = new JLabel("Fecha:");
        lblFecha.setBounds(10, 190, 80, 25);
        contentPane.add(lblFecha);

        txtFecha = new JTextField();
        txtFecha.setBounds(100, 190, 100, 25);
        contentPane.add(txtFecha);
        
        JLabel lblFmtFecha = new JLabel("(DD/MM/AAAA)");
        lblFmtFecha.setForeground(Color.GRAY);
        lblFmtFecha.setBounds(205, 190, 90, 25);
        contentPane.add(lblFmtFecha);

        JLabel lblHora = new JLabel("Hora:");
        lblHora.setBounds(10, 220, 80, 25);
        contentPane.add(lblHora);

        txtHora = new JTextField();
        txtHora.setBounds(100, 220, 100, 25);
        contentPane.add(txtHora);

        JLabel lblFmtHora = new JLabel("(HH:MM)");
        lblFmtHora.setForeground(Color.GRAY);
        lblFmtHora.setBounds(205, 220, 60, 25);
        contentPane.add(lblFmtHora);

        JLabel lblMotivo = new JLabel("Motivo:");
        lblMotivo.setBounds(10, 250, 80, 25);
        contentPane.add(lblMotivo);

        cbMotivo = new JComboBox<>(new String[]{"Consulta General", "Vacuna", "Control", "Seguimiento"});
        cbMotivo.setBounds(100, 250, 150, 25);
        contentPane.add(cbMotivo);

        JButton btnAgendar = new JButton("Agendar");
        btnAgendar.setBounds(10, 300, 110, 25);
        contentPane.add(btnAgendar);

        JButton btnLimpiar = new JButton("Limpiar");
        btnLimpiar.setBounds(140, 300, 110, 25);
        contentPane.add(btnLimpiar);

        // ================= TABLA =================
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(310, 70, 430, 255);
        contentPane.add(scrollPane);

        tablaCitas = new JTable();
        modeloTabla = new DefaultTableModel(
            new Object[][] {},
            new String[] { "ID Cita", "Mascota", "Fecha", "Hora", "Motivo" }
        );
        tablaCitas.setModel(modeloTabla);
        scrollPane.setViewportView(tablaCitas);

        // ================= EVENTOS =================

        btnBuscar.addActionListener(e -> {
            String termino = txtBuscar.getText().trim();
            if (termino.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Ingrese un ID o Nombre para buscar.");
                return;
            }
            
            boolean encontrada = false;
            MascotaDAO mascotaDao = new MascotaDAO();
            List<String[]> mascotas = mascotaDao.listarConDetalles();
            
            for (String[] m : mascotas) {
                if (m[0].equalsIgnoreCase(termino) || m[1].equalsIgnoreCase(termino)) {
                    idMascotaSeleccionada = Integer.parseInt(m[0]);
                    txtMascota.setText(m[1]);
                    txtPropietario.setText(m[6]); // Nombres y apellidos del dueño
                    
                    // Para simplificar y mantener la lógica original, buscamos el correo en los dueños
                    dao.PropietarioDAO pDao = new dao.PropietarioDAO();
                    for (model.Propietario p : pDao.listarTodos()) {
                        if ((p.getNombres() + " " + p.getApellidos()).equals(m[6])) {
                            correoDueno = p.getCorreo();
                            telefonoDueno = p.getTelefono();
                            break;
                        }
                    }
                    
                    encontrada = true;
                    break;
                }
            }

            if (!encontrada) {
                JOptionPane.showMessageDialog(this, "Mascota no encontrada en el sistema.", "No existe", JOptionPane.ERROR_MESSAGE);
                idMascotaSeleccionada = -1;
                txtMascota.setText("");
                txtPropietario.setText("");
                correoDueno = "";
            }
        });

        btnAgendar.addActionListener(e -> {
            if (idMascotaSeleccionada == -1) {
                JOptionPane.showMessageDialog(this, "Debe buscar y seleccionar una mascota primero.");
                return;
            }

            String fecha = txtFecha.getText();
            String hora = txtHora.getText();
            String motivo = cbMotivo.getSelectedItem().toString();

            if (fecha.isEmpty() || hora.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Llene la fecha y la hora.");
                return;
            }

            if (!controller.validarFormatos(fecha, hora)) {
                JOptionPane.showMessageDialog(this, "Formato incorrecto.\nFecha: DD/MM/AAAA\nHora: HH:MM", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Agendamos usando el ID de la mascota numérico
            if(controller.agendarCita(idMascotaSeleccionada, fecha, hora, motivo)) {
                // Notificación
                if (!correoDueno.isEmpty()) {
                    NotificacionService.notificarCitaAgendada(correoDueno, txtMascota.getText(), fecha, hora, motivo);
                }
                
                JOptionPane.showMessageDialog(this, "Cita agendada con éxito.");
                limpiarCampos();
                llenarTabla();
            }
        });

        btnLimpiar.addActionListener(e -> limpiarCampos());
        llenarTabla();
        setLocationRelativeTo(null);
    }

    private void limpiarCampos() {
        txtBuscar.setText("");
        idMascotaSeleccionada = -1;
        correoDueno = "";
        telefonoDueno = "";
        txtMascota.setText("");
        txtPropietario.setText("");
        txtFecha.setText("");
        txtHora.setText("");
    }

    private void llenarTabla() {
        modeloTabla.setRowCount(0);
        CitaDAO citaDao = new CitaDAO();
        List<String[]> lista = citaDao.listarCitas();
        
        for (String[] r : lista) {
            modeloTabla.addRow(r);
        }
    }
}