package view;

import java.awt.Font;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import dao.EspecieDAO;
import model.Especie;

public class ViewEspecies extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtNuevoTipo;
    private JTable tablaEspecies;
    private DefaultTableModel modeloTabla;
    private EspecieDAO dao;

    public ViewEspecies() {
        dao = new EspecieDAO();
        
        setTitle("Catálogo de Tipos de Mascota - PetCare");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 500, 350);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null);
        setContentPane(contentPane);

        JLabel lblTitulo = new JLabel("Administrar Tipos de Mascota");
        lblTitulo.setFont(new Font("Tahoma", Font.BOLD, 14));
        lblTitulo.setBounds(130, 15, 250, 25);
        contentPane.add(lblTitulo);

        JLabel lblNuevo = new JLabel("Nuevo tipo:");
        lblNuevo.setBounds(20, 60, 80, 25);
        contentPane.add(lblNuevo);

        txtNuevoTipo = new JTextField();
        txtNuevoTipo.setBounds(100, 60, 150, 25);
        contentPane.add(txtNuevoTipo);

        JButton btnAgregar = new JButton("Agregar");
        btnAgregar.setBounds(270, 60, 100, 25);
        contentPane.add(btnAgregar);

        // ================= TABLA =================
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(20, 100, 440, 150);
        contentPane.add(scrollPane);

        tablaEspecies = new JTable();
        modeloTabla = new DefaultTableModel(
            new Object[][] {},
            new String[] { "ID", "Tipo de Mascota" }
        );
        tablaEspecies.setModel(modeloTabla);
        scrollPane.setViewportView(tablaEspecies);

        JButton btnEliminar = new JButton("Eliminar seleccionado");
        btnEliminar.setBounds(20, 260, 180, 25);
        contentPane.add(btnEliminar);

        // ================= EVENTOS =================
        btnAgregar.addActionListener(e -> {
            String nombre = txtNuevoTipo.getText().trim();
            if (nombre.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Ingrese el nombre de la especie.");
                return;
            }
            
            // Creamos el objeto (ID 0 porque MySQL lo autogenera)
            Especie nuevaEspecie = new Especie(0, nombre);
            
            if (dao.registrar(nuevaEspecie)) {
                JOptionPane.showMessageDialog(this, "Especie registrada correctamente.");
                txtNuevoTipo.setText("");
                llenarTabla(); // Refrescamos la tabla
            } else {
                JOptionPane.showMessageDialog(this, "Error al registrar en la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnEliminar.addActionListener(e -> {
            int filaSeleccionada = tablaEspecies.getSelectedRow();
            if (filaSeleccionada == -1) {
                JOptionPane.showMessageDialog(this, "Seleccione una especie de la tabla para eliminar.");
                return;
            }
            
            // Obtenemos el ID de la primera columna
            int idEliminar = (int) tablaEspecies.getValueAt(filaSeleccionada, 0);
            
            int confirmacion = JOptionPane.showConfirmDialog(this, "¿Seguro que desea eliminar esta especie?", "Confirmar", JOptionPane.YES_NO_OPTION);
            if (confirmacion == JOptionPane.YES_OPTION) {
                if (dao.eliminar(idEliminar)) {
                    JOptionPane.showMessageDialog(this, "Especie eliminada.");
                    llenarTabla();
                } else {
                    JOptionPane.showMessageDialog(this, "No se puede eliminar. Es posible que haya mascotas registradas con este tipo.", "Error de integridad", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        llenarTabla();
        setLocationRelativeTo(null);
    }

    private void llenarTabla() {
        modeloTabla.setRowCount(0);
        List<Especie> lista = dao.listarTodos();
        
        for (Especie e : lista) {
            // Llenamos usando el ID numérico de MySQL
            modeloTabla.addRow(new Object[] { e.getIdEspecie(), e.getNombre() });
        }
    }
}