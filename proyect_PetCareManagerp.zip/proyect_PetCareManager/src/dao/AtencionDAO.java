package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Atencion;
import util.ConexionBD;

public class AtencionDAO {

    /**
     * Registra una nueva atención médica en la base de datos.
     * Recibe el objeto 'Atencion' completo que enviamos desde el controlador.
     */
    public boolean registrar(Atencion a) {
        String sql = "INSERT INTO atenciones (fecha, diagnostico, tratamiento, observaciones, id_cita, requiere_internamiento) VALUES (?, ?, ?, ?, ?, ?)";
        
        try (Connection cn = ConexionBD.conectar();
             PreparedStatement ps = cn.prepareStatement(sql)) {
             
            // Convertimos la fecha (LocalDate) a formato SQL Date
            ps.setDate(1, Date.valueOf(a.getFecha()));
            ps.setString(2, a.getDiagnostico());
            ps.setString(3, a.getTratamiento());
            ps.setString(4, a.getObservacion());
            ps.setInt(5, a.getIdCita());
            ps.setBoolean(6, a.isInternamiento());
            
            return ps.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.err.println("Error al registrar la atención médica: " + e.getMessage());
            return false;
        }
    }

    /**
     * Obtiene el historial clínico para mostrarlo en la ventana ViewHistorial.
     */
    public List<String[]> obtenerHistorialPorMascota(int idMascota) {
        List<String[]> historial = new ArrayList<>();
        
        // El JOIN conecta la atención con la cita, y la cita nos dice de qué mascota es
        String sql = "SELECT a.id_atencion, a.fecha, a.diagnostico, a.tratamiento, a.observaciones "
                   + "FROM atenciones a "
                   + "INNER JOIN citas c ON a.id_cita = c.id_cita "
                   + "WHERE c.id_mascota = ? "
                   + "ORDER BY a.fecha DESC";
        
        try (Connection cn = ConexionBD.conectar();
             PreparedStatement ps = cn.prepareStatement(sql)) {
             
            ps.setInt(1, idMascota);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String[] registro = new String[5];
                    registro[0] = String.valueOf(rs.getInt("id_atencion"));
                    registro[1] = rs.getDate("fecha").toString(); // Se convierte a texto para la interfaz
                    registro[2] = rs.getString("diagnostico");
                    registro[3] = rs.getString("tratamiento");
                    registro[4] = rs.getString("observaciones");
                    
                    historial.add(registro);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al cargar historial clínico: " + e.getMessage());
        }
        
        return historial;
    }
}