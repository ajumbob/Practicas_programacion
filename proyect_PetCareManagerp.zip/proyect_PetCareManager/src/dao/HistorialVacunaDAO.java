package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.HistorialVacuna;
import util.ConexionBD;

public class HistorialVacunaDAO {

    // 1. REGISTRAR APLICACIÓN DE VACUNA
    public boolean registrar(HistorialVacuna hv) {
        String sql = "INSERT INTO historial_vacunas (fecha, proxima_dosis, id_mascota, id_vacuna) VALUES (?, ?, ?, ?)";
        
        try (Connection cn = ConexionBD.conectar();
             PreparedStatement ps = cn.prepareStatement(sql)) {
             
            ps.setDate(1, Date.valueOf(hv.getFecha()));
            
            // Si hay próxima dosis, la guardamos. Si es null, enviamos nulo a MySQL.
            if (hv.getProximaDosis() != null) {
                ps.setDate(2, Date.valueOf(hv.getProximaDosis()));
            } else {
                ps.setNull(2, java.sql.Types.DATE);
            }
            
            ps.setInt(3, hv.getIdMascota());
            ps.setInt(4, hv.getIdVacuna());
            
            return ps.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.err.println("Error al registrar vacuna en historial: " + e.getMessage());
            return false;
        }
    }

    // 2. LEER HISTORIAL DE UNA MASCOTA (Con JOIN al catálogo)
    public List<String[]> listarPorMascota(int idMascota) {
        List<String[]> lista = new ArrayList<>();
        String sql = "SELECT v.nombre, h.fecha FROM historial_vacunas h "
                   + "INNER JOIN vacunas v ON h.id_vacuna = v.id_vacuna "
                   + "WHERE h.id_mascota = ? ORDER BY h.fecha DESC";
                   
        try (Connection cn = ConexionBD.conectar();
             PreparedStatement ps = cn.prepareStatement(sql)) {
             
            ps.setInt(1, idMascota);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(new String[]{
                        rs.getString("nombre"),
                        rs.getDate("fecha").toString()
                    });
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al listar historial de vacunas: " + e.getMessage());
        }
        return lista;
    }
}