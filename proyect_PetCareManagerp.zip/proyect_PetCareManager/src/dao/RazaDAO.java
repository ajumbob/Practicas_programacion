package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Raza;
import util.ConexionBD;

public class RazaDAO {

    public List<Raza> listarPorEspecie(int idEspecie) {
        List<Raza> lista = new ArrayList<>();
        String sql = "SELECT * FROM razas WHERE id_especie = ?";
        
        try (Connection cn = ConexionBD.conectar();
             PreparedStatement ps = cn.prepareStatement(sql)) {
             
            ps.setInt(1, idEspecie);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(new Raza(rs.getInt("id_raza"), rs.getString("nombre"), rs.getInt("id_especie")));
                }
            }
        } catch (SQLException ex) {
            System.err.println("Error al listar razas por especie: " + ex.getMessage());
        }
        return lista;
    }
}