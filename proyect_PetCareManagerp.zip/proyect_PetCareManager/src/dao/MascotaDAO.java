package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Mascota;
import util.ConexionBD;

public class MascotaDAO {

    // 1. CREAR
    public boolean registrar(Mascota m) {
        String sql = "INSERT INTO mascotas (nombre, sexo, fecha_nacimiento, color, peso, id_propietario, id_especie, id_raza) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection cn = ConexionBD.conectar();
             PreparedStatement ps = cn.prepareStatement(sql)) {
             
            ps.setString(1, m.getNombre());
            ps.setString(2, m.getSexo());
            // Transformamos el LocalDate de Java al Date de SQL
            ps.setDate(3, java.sql.Date.valueOf(m.getFechaNacimiento()));
            ps.setString(4, m.getColor());
            ps.setDouble(5, m.getPeso());
            
            // Inyección de las llaves foráneas (IDs numéricos)
            ps.setInt(6, m.getIdPropietario());
            ps.setInt(7, m.getIdEspecie());
            ps.setInt(8, m.getIdRaza());
            
            return ps.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.err.println("Error al registrar mascota: " + e.getMessage());
            return false;
        }
    }

    // 2. LEER CON DETALLES (Ideal para llenar tu JTable en ViewMascota)
    // En lugar de devolver solo IDs, hacemos JOINs para traer los nombres reales.
    public List<String[]> listarConDetalles() {
        List<String[]> lista = new ArrayList<>();
        
        String sql = "SELECT m.id_mascota, m.nombre, e.nombre AS especie, r.nombre AS raza, "
                   + "m.fecha_nacimiento, m.sexo, p.nombres AS dueño_nombres, p.apellidos AS dueño_apellidos "
                   + "FROM mascotas m "
                   + "INNER JOIN especies e ON m.id_especie = e.id_especie "
                   + "INNER JOIN razas r ON m.id_raza = r.id_raza "
                   + "INNER JOIN propietarios p ON m.id_propietario = p.id_propietario";
        
        try (Connection cn = ConexionBD.conectar();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
             
            while (rs.next()) {
                String[] fila = new String[7];
                fila[0] = String.valueOf(rs.getInt("id_mascota"));
                fila[1] = rs.getString("nombre");
                fila[2] = rs.getString("especie");
                fila[3] = rs.getString("raza");
                fila[4] = rs.getDate("fecha_nacimiento").toString(); // Devuelve YYYY-MM-DD
                fila[5] = rs.getString("sexo");
                fila[6] = rs.getString("dueño_nombres") + " " + rs.getString("dueño_apellidos");
                
                lista.add(fila);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar mascotas con detalles: " + e.getMessage());
        }
        return lista;
    }

    // 3. ACTUALIZAR
    public boolean actualizar(Mascota m) {
        String sql = "UPDATE mascotas SET nombre=?, sexo=?, fecha_nacimiento=?, color=?, peso=?, id_propietario=?, id_especie=?, id_raza=? WHERE id_mascota=?";
        
        try (Connection cn = ConexionBD.conectar();
             PreparedStatement ps = cn.prepareStatement(sql)) {
             
            ps.setString(1, m.getNombre());
            ps.setString(2, m.getSexo());
            ps.setDate(3, java.sql.Date.valueOf(m.getFechaNacimiento()));
            ps.setString(4, m.getColor());
            ps.setDouble(5, m.getPeso());
            ps.setInt(6, m.getIdPropietario());
            ps.setInt(7, m.getIdEspecie());
            ps.setInt(8, m.getIdRaza());
            ps.setInt(9, m.getIdMascota());
            
            return ps.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.err.println("Error al actualizar mascota: " + e.getMessage());
            return false;
        }
    }

    // 4. ELIMINAR
    public boolean eliminar(int idMascota) {
        String sql = "DELETE FROM mascotas WHERE id_mascota = ?";
        
        try (Connection cn = ConexionBD.conectar();
             PreparedStatement ps = cn.prepareStatement(sql)) {
             
            ps.setInt(1, idMascota);
            return ps.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.err.println("Error al eliminar mascota: " + e.getMessage());
            return false;
        }
    }
}