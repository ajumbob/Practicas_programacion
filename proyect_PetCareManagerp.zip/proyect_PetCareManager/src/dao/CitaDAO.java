package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Time;
import model.Cita;
import util.ConexionBD;

public class CitaDAO {
	// Agrega este método dentro de CitaDAO.java
    public java.util.List<String[]> listarCitas() {
        java.util.List<String[]> lista = new java.util.ArrayList<>();
        String sql = "SELECT c.id_cita, m.nombre AS mascota, c.fecha, c.hora, c.motivo "
                   + "FROM citas c "
                   + "INNER JOIN mascotas m ON c.id_mascota = m.id_mascota "
                   + "ORDER BY c.fecha ASC, c.hora ASC";
                   
        try (java.sql.Connection cn = util.ConexionBD.conectar();
             java.sql.PreparedStatement ps = cn.prepareStatement(sql);
             java.sql.ResultSet rs = ps.executeQuery()) {
             
            while (rs.next()) {
                lista.add(new String[]{
                    String.valueOf(rs.getInt("id_cita")),
                    rs.getString("mascota"),
                    rs.getDate("fecha").toString(),
                    rs.getTime("hora").toString(),
                    rs.getString("motivo")
                });
            }
        } catch (java.sql.SQLException e) {
            System.err.println("Error al listar citas: " + e.getMessage());
        }
        return lista;
    }
    public String[] buscarCitaPorId(int idCita) {
        String sql = "SELECT c.id_cita, c.fecha, m.id_mascota, m.nombre AS mascota_nombre, "
                   + "p.correo, p.telefono "
                   + "FROM citas c "
                   + "INNER JOIN mascotas m ON c.id_mascota = m.id_mascota "
                   + "INNER JOIN propietarios p ON m.id_propietario = p.id_propietario "
                   + "WHERE c.id_cita = ?";
                   
        try (java.sql.Connection cn = util.ConexionBD.conectar();
             java.sql.PreparedStatement ps = cn.prepareStatement(sql)) {
             
            ps.setInt(1, idCita);
            try (java.sql.ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new String[] {
                        String.valueOf(rs.getInt("id_cita")),
                        rs.getDate("fecha").toString(),
                        String.valueOf(rs.getInt("id_mascota")),
                        rs.getString("mascota_nombre"),
                        rs.getString("correo"),
                        rs.getString("telefono") // Para WhatsApp
                    };
                }
            }
        } catch (java.sql.SQLException e) {
            System.err.println("Error al buscar cita: " + e.getMessage());
        }
        return null; // Si no encuentra la cita
    }

    // 1. CREAR (Agendar una nueva cita)
    public boolean agendarCita(Cita c) {
        // No incluimos id_veterinario hasta que lo agregues a tu interfaz gráfica
        String sql = "INSERT INTO citas (fecha, hora, motivo, estado, id_mascota) VALUES (?, ?, ?, ?, ?)";
        
        try (Connection cn = ConexionBD.conectar();
             PreparedStatement ps = cn.prepareStatement(sql)) {
             
            // Transformamos los tipos de java.time a los tipos de java.sql
            ps.setDate(1, Date.valueOf(c.getFecha()));
            ps.setTime(2, Time.valueOf(c.getHora()));
            
            ps.setString(3, c.getMotivo());
            ps.setString(4, c.getEstado()); // Por defecto será "Pendiente"
            ps.setInt(5, c.getIdMascota());
            
            return ps.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.err.println("Error al guardar la cita en BD: " + e.getMessage());
            return false;
        }
    }
    
    // Aquí puedes agregar más adelante los métodos listar(), actualizar() y eliminar()
}