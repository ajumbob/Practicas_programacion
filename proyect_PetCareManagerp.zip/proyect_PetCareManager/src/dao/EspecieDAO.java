package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Especie;
import util.ConexionBD;

public class EspecieDAO {

    public boolean registrar(Especie e) {
        String sql = "INSERT INTO especies (nombre) VALUES (?)";
        try (Connection cn = ConexionBD.conectar();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, e.getNombre());
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            System.err.println("Error al registrar especie: " + ex.getMessage());
            return false;
        }
    }

    public List<Especie> listarTodos() {
        List<Especie> lista = new ArrayList<>();
        String sql = "SELECT * FROM especies";
        try (Connection cn = ConexionBD.conectar();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(new Especie(rs.getInt("id_especie"), rs.getString("nombre")));
            }
        } catch (SQLException ex) {
            System.err.println("Error al listar especies: " + ex.getMessage());
        }
        return lista;
    }

    public boolean eliminar(int id) {
        String sql = "DELETE FROM especies WHERE id_especie = ?";
        try (Connection cn = ConexionBD.conectar();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            System.err.println("Error al eliminar especie: " + ex.getMessage());
            return false;
        }
    }
}