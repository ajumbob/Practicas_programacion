package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Vacuna;
import util.ConexionBD;

public class VacunaDAO {

    public boolean registrar(Vacuna v) {
        String sql = "INSERT INTO vacunas (nombre, descripcion) VALUES (?, ?)";
        try (Connection cn = ConexionBD.conectar();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, v.getNombre());
            ps.setString(2, v.getDescripcion());
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            System.err.println("Error al registrar vacuna: " + ex.getMessage());
            return false;
        }
    }

    public List<Vacuna> listarTodos() {
        List<Vacuna> lista = new ArrayList<>();
        String sql = "SELECT * FROM vacunas";
        try (Connection cn = ConexionBD.conectar();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(new Vacuna(rs.getInt("id_vacuna"), rs.getString("nombre"), rs.getString("descripcion")));
            }
        } catch (SQLException ex) {
            System.err.println("Error al listar vacunas: " + ex.getMessage());
        }
        return lista;
    }

    public boolean eliminar(int id) {
        String sql = "DELETE FROM vacunas WHERE id_vacuna = ?";
        try (Connection cn = ConexionBD.conectar();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            System.err.println("Error al eliminar vacuna: " + ex.getMessage());
            return false;
        }
    }
}