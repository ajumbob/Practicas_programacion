package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Propietario;
import util.ConexionBD;

public class PropietarioDAO {

    // 1. CREAR (Insertar un nuevo registro)
    public boolean registrar(Propietario p) {
        String sql = "INSERT INTO propietarios (cedula, nombres, apellidos, telefono, direccion, correo) VALUES (?, ?, ?, ?, ?, ?)";
        
        try (Connection cn = ConexionBD.conectar();
             PreparedStatement ps = cn.prepareStatement(sql)) {
             
            ps.setString(1, p.getCedula());
            ps.setString(2, p.getNombres());
            ps.setString(3, p.getApellidos());
            ps.setString(4, p.getTelefono());
            ps.setString(5, p.getDireccion());
            ps.setString(6, p.getCorreo());
            
            // executeUpdate() devuelve el número de filas afectadas
            return ps.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.err.println("Error al registrar propietario: " + e.getMessage());
            return false;
        }
    }

    // 2. LEER (Obtener todos los registros para llenar tablas)
    public List<Propietario> listarTodos() {
        List<Propietario> lista = new ArrayList<>();
        String sql = "SELECT * FROM propietarios";
        
        try (Connection cn = ConexionBD.conectar();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
             
            while (rs.next()) {
                Propietario p = new Propietario();
                p.setIdPropietario(rs.getInt("id_propietario"));
                p.setCedula(rs.getString("cedula"));
                p.setNombres(rs.getString("nombres"));
                p.setApellidos(rs.getString("apellidos"));
                p.setTelefono(rs.getString("telefono"));
                p.setDireccion(rs.getString("direccion"));
                p.setCorreo(rs.getString("correo"));
                
                lista.add(p);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar propietarios: " + e.getMessage());
        }
        return lista;
    }

    // 3. ACTUALIZAR (Modificar un registro existente)
    public boolean actualizar(Propietario p) {
        String sql = "UPDATE propietarios SET nombres=?, apellidos=?, telefono=?, direccion=?, correo=? WHERE cedula=?";
        
        try (Connection cn = ConexionBD.conectar();
             PreparedStatement ps = cn.prepareStatement(sql)) {
             
            ps.setString(1, p.getNombres());
            ps.setString(2, p.getApellidos());
            ps.setString(3, p.getTelefono());
            ps.setString(4, p.getDireccion());
            ps.setString(5, p.getCorreo());
            ps.setString(6, p.getCedula()); // Usamos la cédula para buscar a quién actualizar
            
            return ps.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.err.println("Error al actualizar propietario: " + e.getMessage());
            return false;
        }
    }

    // 4. ELIMINAR (Borrar un registro)
    public boolean eliminar(int idPropietario) {
        String sql = "DELETE FROM propietarios WHERE id_propietario = ?";
        
        try (Connection cn = ConexionBD.conectar();
             PreparedStatement ps = cn.prepareStatement(sql)) {
             
            ps.setInt(1, idPropietario);
            return ps.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.err.println("Error al eliminar propietario: " + e.getMessage());
            return false;
        }
    }
}
