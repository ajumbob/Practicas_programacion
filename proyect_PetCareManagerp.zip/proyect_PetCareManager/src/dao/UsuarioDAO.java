package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import model.Usuario;
import util.ConexionBD;

public class UsuarioDAO {

    /**
     * Valida las credenciales en la base de datos.
     * Retorna el objeto Usuario si el login es exitoso, o null si falla.
     */
    public Usuario validarLogin(String username, String password) {
        Usuario usuarioLogueado = null;
        
        // Consulta SQL para buscar al usuario por sus credenciales
        String sql = "SELECT * FROM usuarios WHERE usuario = ? AND password = ?";
        
        try (Connection cn = ConexionBD.conectar();
             PreparedStatement ps = cn.prepareStatement(sql)) {
             
            // Inyectamos los parámetros de forma segura
            ps.setString(1, username);
            ps.setString(2, password);
            
            try (ResultSet rs = ps.executeQuery()) {
                // Si rs.next() es true, significa que encontró un registro coincidente
                if (rs.next()) {
                    usuarioLogueado = new Usuario(
                        rs.getInt("id_usuario"),
                        rs.getString("nombre"),
                        rs.getString("usuario"),
                        rs.getString("password"),
                        rs.getString("correo"),
                        rs.getInt("id_rol")
                    );
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Error al validar login en BD: " + e.getMessage());
        }
        
        return usuarioLogueado;
    }
}
