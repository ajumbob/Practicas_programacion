package sportcenter;

public interface IGestion<T> {
    void registrar(T elemento);
    void listarTodo();
    int contarReservados();
}