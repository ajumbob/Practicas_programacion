package sportcenter;

import java.util.Scanner;

public class Main {
    private static GestionCanchas<Cancha> sistema = new GestionCanchas<>();
    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int opcion;
        do {
            System.out.println("\n--- SportCenter Solutions ---");
            System.out.println("1. Registrar Cancha");
            System.out.println("2. Consultar Listado");
            System.out.println("3. Reservar Cancha");
            System.out.println("4. Liberar Cancha");
            System.out.println("5. Ver Estadísticas");
            System.out.println("0. Salir");
            System.out.print("Seleccione: ");
            opcion = sc.nextInt();
            sc.nextLine(); // Limpiar buffer

            switch (opcion) {
                case 1 -> menuRegistrar();
                case 2 -> sistema.listarTodo();
                case 3 -> gestionarEstado(true);
                case 4 -> gestionarEstado(false);
                case 5 -> mostrarEstadisticas();
            }
        } while (opcion != 0);
    }

    private static void menuRegistrar() {
        System.out.print("Código: "); String cod = sc.nextLine();
        System.out.print("Tipo: "); String tipo = sc.nextLine();
        System.out.print("Ubicación: "); String ubi = sc.nextLine();
        System.out.print("Costo/Hora: "); double costo = sc.nextDouble();
        sistema.registrar(new Cancha(cod, tipo, ubi, costo));
    }

    private static void gestionarEstado(boolean reservar) {
        System.out.print("Ingrese el código de la cancha: ");
        String cod = sc.nextLine();
        Cancha c = sistema.buscarPorCodigo(cod);
        if (c != null) {
            c.setReservada(reservar);
            System.out.println(reservar ? "Cancha Reservada." : "Cancha Liberada.");
        } else {
            System.out.println("Cancha no encontrada.");
        }
    }

    private static void mostrarEstadisticas() {
        System.out.println("Total de canchas: " + sistema.totalCanchas());
        System.out.println("Canchas reservadas: " + sistema.contarReservados());
    }
}