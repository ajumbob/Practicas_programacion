package sportcenter;

public class Cancha {
    private String codigo;
    private String tipo;
    private String ubicacion;
    private double costoPorHora;
    private boolean reservada;

    public Cancha(String codigo, String tipo, String ubicacion, double costoPorHora) {
        this.codigo = codigo;
        this.tipo = tipo;
        this.ubicacion = ubicacion;
        this.costoPorHora = costoPorHora;
        this.reservada = false; // Por defecto disponible [cite: 24]
    }

    // Getters y Setters
    public String getCodigo() { return codigo; }
    public boolean isReservada() { return reservada; }
    public void setReservada(boolean reservada) { this.reservada = reservada; }

    @Override
    public String toString() {
        return String.format("ID: %s | Tipo: %s | Ubicación: %s | Costo: $%.2f | Estado: %s",
                codigo, tipo, ubicacion, costoPorHora, (reservada ? "RESERVADA" : "DISPONIBLE"));
    }
}