package sportcenter;

import java.util.ArrayList;
import java.util.List;

public class GestionCanchas<T extends Cancha> implements IGestion<T> {
    private List<T> listaCanchas = new ArrayList<>();
    private final int MAX_CANCHAS = 50; 
    @Override
    public void registrar(T cancha) {
        if (listaCanchas.size() < MAX_CANCHAS) {
            listaCanchas.add(cancha);
            System.out.println("Cancha registrada con éxito.");
        } else {
            System.out.println("Error: Capacidad máxima alcanzada.");
        }
    }

    @Override
    public void listarTodo() {
        for (T c : listaCanchas) {
            System.out.println(c.toString());
        }
    }

    @Override
    public int contarReservados() {
        int contador = 0;
        for (T c : listaCanchas) {
            if (c.isReservada()) contador++;
        }
        return contador;
    }

    public T buscarPorCodigo(String codigo) {
        for (T c : listaCanchas) {
            if (c.getCodigo().equalsIgnoreCase(codigo)) return c;
        }
        return null;
    }

    public int totalCanchas() {
        return listaCanchas.size();
    }
}