package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import model.Movie;
import connection.Conexion;
import javax.swing.table.DefaultTableModel;

public class MovieDAO {

  
    public DefaultTableModel executeCustomQuery(String sql) throws SQLException {
        try (Connection con = Conexion.conectar();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            ResultSetMetaData meta = rs.getMetaData();
            int columnCount = meta.getColumnCount();

            DefaultTableModel model = new DefaultTableModel();
            for (int i = 1; i <= columnCount; i++) {
                model.addColumn(meta.getColumnLabel(i));
            }

            while (rs.next()) {
                Object[] fila = new Object[columnCount];
                for (int i = 1; i <= columnCount; i++) {
                    fila[i - 1] = rs.getObject(i);
                }
                model.addRow(fila);
            }
            return model;
        }
    }

    /**
     * Calcula automáticamente el siguiente id_movie disponible.
     */
    public int getNextId() throws SQLException {
        String sql = "SELECT IFNULL(MAX(id_movie), 0) + 1 AS siguiente FROM movie";
        try (Connection con = Conexion.conectar();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            if (rs.next()) {
                return rs.getInt("siguiente");
            }
        }
        return 1;
    }

    /**
     * Inserta una nueva película generando el id automáticamente.
     */
    public void insertMovie(Movie movie) throws SQLException {
        int nextId = getNextId();
        movie.setIdMovie(nextId);

        String sql = "INSERT INTO movie (id_movie, id_genre, title, summary, year, duration) "
                + "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, movie.getIdMovie());
            ps.setInt(2, movie.getIdGenre());
            ps.setString(3, movie.getTitle());
            ps.setString(4, movie.getSummary());
            ps.setInt(5, movie.getYear());
            ps.setInt(6, movie.getDuration());
            ps.executeUpdate();
        }
    }
}
