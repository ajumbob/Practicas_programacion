package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import connection.Conexion;
import model.Genre;

public class GenreDAO {

   
    public List<Genre> getAllGenres() throws SQLException {
        List<Genre> lista = new ArrayList<>();
        String sql = "SELECT id_genre, name FROM genre ORDER BY id_genre";

        try (Connection con = Conexion.conectar();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                lista.add(new Genre(rs.getInt("id_genre"), rs.getString("name")));
            }
        }
        return lista;
    }

    /**
     * Calcula automáticamente el siguiente id_genre disponible.
     */
    public int getNextId() throws SQLException {
        String sql = "SELECT IFNULL(MAX(id_genre), 0) + 1 AS siguiente FROM genre";
        try (Connection con = Conexion.conectar();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            if (rs.next()) {
                return rs.getInt("siguiente");
            }
        }
        return 1;
    }

    /**
     * Inserta un nuevo género generando el id automáticamente.
     */
    public void insertGenre(String name) throws SQLException {
        int nextId = getNextId();
        String sql = "INSERT INTO genre (id_genre, name) VALUES (?, ?)";

        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, nextId);
            ps.setString(2, name);
            ps.executeUpdate();
        }
    }
}
