package model;

public class Movie {

    private int idMovie;
    private int idGenre;
    private String title;
    private String summary;
    private int year;
    private int duration;

    public Movie() {
    }

    public Movie(int idMovie, int idGenre, String title, String summary, int year, int duration) {
        this.idMovie = idMovie;
        this.idGenre = idGenre;
        this.title = title;
        this.summary = summary;
        this.year = year;
        this.duration = duration;
    }

    public int getIdMovie() {
        return idMovie;
    }

    public void setIdMovie(int idMovie) {
        this.idMovie = idMovie;
    }

    public int getIdGenre() {
        return idGenre;
    }

    public void setIdGenre(int idGenre) {
        this.idGenre = idGenre;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }
}
