package view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

import dao.MovieDAO;


public class MainFrame extends JFrame {

    private JRadioButton rbMovies;
    private JRadioButton rbGenre;
    private JTextField txtQuery;
    private JButton btnSubmit;
    private JTable table;
    private JTextField txtFilter;
    private JButton btnNewGenre;
    private JButton btnNewMovie;

    private final MovieDAO movieDAO = new MovieDAO();
    private TableRowSorter<DefaultTableModel> sorter;

    private static final String QUERY_MOVIES = "SELECT * FROM movie";
    private static final String QUERY_GENRE = "SELECT * FROM genre";

    public MainFrame() {
        super("Sistema Movie - Práctica 07");
        initComponents();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(750, 500);
        setLocationRelativeTo(null);

        // Carga inicial: Movies seleccionado por defecto (Ilustración 1)
        rbMovies.setSelected(true);
        txtQuery.setText(QUERY_MOVIES);
        ejecutarConsulta(QUERY_MOVIES);
    }

    private void initComponents() {
        setLayout(new BorderLayout(8, 8));

        // --- Panel superior: radio buttons ---
        JPanel panelRadios = new JPanel(new FlowLayout(FlowLayout.LEFT));
        rbMovies = new JRadioButton("Movies");
        rbGenre = new JRadioButton("Genre");
        ButtonGroup group = new ButtonGroup();
        group.add(rbMovies);
        group.add(rbGenre);
        panelRadios.add(rbMovies);
        panelRadios.add(rbGenre);

        rbMovies.addActionListener(e -> {
            txtQuery.setText(QUERY_MOVIES);
            ejecutarConsulta(QUERY_MOVIES);
        });
        rbGenre.addActionListener(e -> {
            txtQuery.setText(QUERY_GENRE);
            ejecutarConsulta(QUERY_GENRE);
        });

        // --- Panel de consulta (query + submit) ---
        JPanel panelQuery = new JPanel(new BorderLayout(6, 6));
        txtQuery = new JTextField(QUERY_MOVIES);
        btnSubmit = new JButton("Submit");
        panelQuery.add(txtQuery, BorderLayout.CENTER);
        panelQuery.add(btnSubmit, BorderLayout.EAST);

        btnSubmit.addActionListener(e -> ejecutarConsulta(txtQuery.getText().trim()));

        JPanel panelTop = new JPanel(new BorderLayout(4, 4));
        panelTop.add(panelRadios, BorderLayout.NORTH);
        panelTop.add(panelQuery, BorderLayout.SOUTH);

        // --- Tabla central ---
        table = new JTable(new DefaultTableModel());
        JScrollPane scrollPane = new JScrollPane(table);

        // --- Panel inferior: filtro + botones ---
        JPanel panelBottom = new JPanel(new BorderLayout(6, 6));
        JPanel panelFilter = new JPanel(new BorderLayout(6, 6));
        panelFilter.add(new javax.swing.JLabel("Filtro:"), BorderLayout.WEST);
        txtFilter = new JTextField();
        panelFilter.add(txtFilter, BorderLayout.CENTER);

        JPanel panelActionButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnNewGenre = new JButton("New Genre");
        btnNewMovie = new JButton("New Movie");
        panelActionButtons.add(btnNewGenre);
        panelActionButtons.add(btnNewMovie);

        panelBottom.add(panelFilter, BorderLayout.CENTER);
        panelBottom.add(panelActionButtons, BorderLayout.EAST);
        panelBottom.setBorder(BorderFactory.createEmptyBorder(6, 0, 0, 0));

        btnNewGenre.addActionListener(e -> abrirNewGenre());
        btnNewMovie.addActionListener(e -> abrirNewMovie());

        // Filtro tipo buscador: se aplica en vivo sobre TODAS las columnas visibles
        txtFilter.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) { aplicarFiltro(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { aplicarFiltro(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { aplicarFiltro(); }
        });

        add(panelTop, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(panelBottom, BorderLayout.SOUTH);
    }

  
    private void ejecutarConsulta(String sql) {
        if (sql == null || sql.isEmpty()) {
            return;
        }
        try {
            DefaultTableModel model = movieDAO.executeCustomQuery(sql);
            table.setModel(model);
            sorter = new TableRowSorter<>(model);
            table.setRowSorter(sorter);
            txtFilter.setText("");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error en la consulta:\n" + ex.getMessage(),
                    "Error SQL", JOptionPane.ERROR_MESSAGE);
        }
    }

  
    private void aplicarFiltro() {
        if (sorter == null) {
            return;
        }
        String texto = txtFilter.getText().trim();
        if (texto.isEmpty()) {
            sorter.setRowFilter(null);
        } else {
            sorter.setRowFilter(RowFilter.regexFilter("(?i)" + java.util.regex.Pattern.quote(texto)));
        }
    }

    private void abrirNewGenre() {
        NewGenreDialog dialog = new NewGenreDialog(this);
        dialog.setVisible(true);
        if (dialog.isGuardado() && rbGenre.isSelected()) {
            ejecutarConsulta(QUERY_GENRE);
        }
    }

    private void abrirNewMovie() {
        NewMovieDialog dialog = new NewMovieDialog(this);
        dialog.setVisible(true);
        if (dialog.isGuardado() && rbMovies.isSelected()) {
            ejecutarConsulta(QUERY_MOVIES);
        }
    }
}
