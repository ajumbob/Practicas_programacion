package view;

import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.sql.SQLException;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;

import dao.GenreDAO;
import dao.MovieDAO;
import model.Genre;
import model.Movie;

public class NewMovieDialog extends JDialog {

    private JComboBox<Genre> cmbGenre;
    private JTextField txtTitle;
    private JTextArea txtSummary;
    private JSpinner spnYear;
    private JSpinner spnDuration;

    private final GenreDAO genreDAO = new GenreDAO();
    private final MovieDAO movieDAO = new MovieDAO();
    private boolean guardado = false;

    public NewMovieDialog(JFrame parent) {
        super(parent, "New Movie", true);
        initComponents();
        cargarGeneros();
        setSize(420, 480);
        setLocationRelativeTo(parent);
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));

        JPanel panelForm = new JPanel(new GridBagLayout());
        panelForm.setBorder(javax.swing.BorderFactory.createEmptyBorder(15, 15, 15, 15));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        cmbGenre = new JComboBox<>();
        txtTitle = new JTextField(18);
        txtSummary = new JTextArea(5, 18);
        txtSummary.setLineWrap(true);
        txtSummary.setWrapStyleWord(true);
        spnYear = new JSpinner(new SpinnerNumberModel(2024, 1900, 2100, 1));
        spnDuration = new JSpinner(new SpinnerNumberModel(90, 1, 600, 1));

        int row = 0;
        gbc.gridx = 0; gbc.gridy = row; panelForm.add(new JLabel("Genre:"), gbc);
        gbc.gridx = 1; gbc.gridy = row; panelForm.add(cmbGenre, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row; panelForm.add(new JLabel("Title:"), gbc);
        gbc.gridx = 1; gbc.gridy = row; panelForm.add(txtTitle, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row; panelForm.add(new JLabel("Summary:"), gbc);
        gbc.gridx = 1; gbc.gridy = row; panelForm.add(new JScrollPane(txtSummary), gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row; panelForm.add(new JLabel("Year:"), gbc);
        gbc.gridx = 1; gbc.gridy = row; panelForm.add(spnYear, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row; panelForm.add(new JLabel("Duration:"), gbc);
        gbc.gridx = 1; gbc.gridy = row; panelForm.add(spnDuration, gbc);

        JPanel panelButtons = new JPanel();
        JButton btnSave = new JButton("Save");
        JButton btnCancel = new JButton("Cancel");
        panelButtons.add(btnSave);
        panelButtons.add(btnCancel);

        btnSave.addActionListener(e -> guardar());
        btnCancel.addActionListener(e -> dispose());

        add(panelForm, BorderLayout.CENTER);
        add(panelButtons, BorderLayout.SOUTH);
    }

    private void cargarGeneros() {
        try {
            List<Genre> generos = genreDAO.getAllGenres();
            for (Genre g : generos) {
                cmbGenre.addItem(g);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al cargar géneros: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void guardar() {
        String title = txtTitle.getText().trim();
        String summary = txtSummary.getText().trim();
        Genre genreSeleccionado = (Genre) cmbGenre.getSelectedItem();

        if (title.isEmpty() || summary.isEmpty() || genreSeleccionado == null) {
            JOptionPane.showMessageDialog(this, "Complete todos los campos.",
                    "Campos requeridos", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Movie movie = new Movie();
        movie.setIdGenre(genreSeleccionado.getIdGenre());
        movie.setTitle(title);
        movie.setSummary(summary);
        movie.setYear((Integer) spnYear.getValue());
        movie.setDuration((Integer) spnDuration.getValue());

        try {
            movieDAO.insertMovie(movie);
            guardado = true;
            dispose();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al guardar: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public boolean isGuardado() {
        return guardado;
    }
}
