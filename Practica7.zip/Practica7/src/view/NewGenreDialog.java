package view;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import dao.GenreDAO;


public class NewGenreDialog extends JDialog {

    private JTextField txtName;
    private final GenreDAO genreDAO = new GenreDAO();
    private boolean guardado = false;

    public NewGenreDialog(JFrame parent) {
        super(parent, "New Genre", true);
        initComponents();
        setSize(350, 200);
        setLocationRelativeTo(parent);
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));

        JPanel panelForm = new JPanel(new GridLayout(1, 2, 10, 10));
        panelForm.setBorder(javax.swing.BorderFactory.createEmptyBorder(20, 20, 10, 20));
        panelForm.add(new JLabel("Name:"));
        txtName = new JTextField();
        panelForm.add(txtName);

        JPanel panelButtons = new JPanel();
        JButton btnSave = new JButton("Save");
        JButton btnCancel = new JButton("Cancel");
        panelButtons.add(btnSave);
        panelButtons.add(btnCancel);

        btnSave.addActionListener(e -> guardar());
        btnCancel.addActionListener(e -> dispose());

        add(panelForm, BorderLayout.CENTER);
        add(panelButtons, BorderLayout.SOUTH);
    }

    private void guardar() {
        String name = txtName.getText().trim();
        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ingrese un nombre de género.",
                    "Campo requerido", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            genreDAO.insertGenre(name.toUpperCase());
            guardado = true;
            dispose();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al guardar: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public boolean isGuardado() {
        return guardado;
    }
}
