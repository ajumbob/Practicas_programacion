package main;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

import view.MainFrame;

public class App {
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
            // Si falla, se usa el look and feel por defecto de Swing
        }
        SwingUtilities.invokeLater(() -> new MainFrame().setVisible(true));
    }
}
